"""Build one supervised source cache from explicitly adapted source domains."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from data.domain import (  # noqa: E402
    adapt_common_channel_average_reference,
    namespace_epoch_dataset,
)
from data.epochs import (  # noqa: E402
    concatenate_epoch_datasets,
    load_epoch_dataset,
    save_epoch_dataset,
)


def _source_spec(value: str) -> tuple[str, Path]:
    namespace, separator, path = value.partition("=")
    if not separator or not namespace.strip() or not path.strip():
        raise argparse.ArgumentTypeError("--source must use NAMESPACE=cache.npz")
    return namespace.strip(), Path(path.strip())


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", action="append", type=_source_spec, required=True)
    parser.add_argument("--target-channels", required=True)
    parser.add_argument("--name", default="MultiSource-P300")
    parser.add_argument("--output", required=True)
    parser.add_argument("--uncompressed", action="store_true")
    args = parser.parse_args()
    if len(args.source) < 2:
        parser.error("multi-domain source preparation requires at least two --source values")
    namespaces = [namespace for namespace, _ in args.source]
    if len(set(namespaces)) != len(namespaces):
        parser.error("source namespaces must be unique")
    channels = tuple(value.strip() for value in args.target_channels.split(",") if value.strip())

    adapted = []
    source_records = []
    for namespace, path in args.source:
        dataset = load_epoch_dataset(path, require_labels=True, validation="attested")
        aligned = adapt_common_channel_average_reference(
            dataset,
            channels,
        )
        aligned = namespace_epoch_dataset(aligned, namespace)
        adapted.append(aligned)
        source_records.append(
            {
                "namespace": namespace,
                "cache": str(path.resolve()),
                "dataset_name": dataset.name,
                "n_subjects": len(set(dataset.subject_ids)),
                "n_epochs": dataset.n_epochs,
                "parent_source_reference": dataset.provenance.get("source_reference"),
            }
        )
    reference = adapted[0].provenance["source_reference"]
    merged = concatenate_epoch_datasets(
        adapted,
        name=args.name,
        provenance={
            "source": "explicit_multidomain_common_channel_car",
            "source_reference": reference,
            "target_channels": list(adapted[0].channel_names),
            "sources": source_records,
        },
    )
    output = save_epoch_dataset(args.output, merged, compressed=not args.uncompressed)
    print(
        f"[multidomain] {output} X={merged.X.shape} "
        f"subjects={len(set(merged.subject_ids))}",
        flush=True,
    )


if __name__ == "__main__":
    main()
