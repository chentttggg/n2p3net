"""辅助 P300 数据加载器（P9 / transfer_policy 方式 A/B/C 的数据入口）。

职责：
    读取 experiments/download_datasets.py 落盘的 MOABB .npz 缓存，统一为
    AuxiliaryData{X:(N,C,T) float32, y:(N,) int64, metadata, channel_names}。
    辅助域只有 target/non-target 二分类标签（1=Target, 0=NonTarget），
    **不提供 thought number**，也不进入 GTN 主分类/测试 fold。

明确「不做」：
    - 不读取 GTN thought 元数据；
    - 不做联合训练 / 拼接逻辑（由 train 层按 transfer_policy 执行）；
    - 不做真实数据下载（experiments/download_datasets.py 负责）。

三思决策记录：
    D-aux-y          MOABB y 可能是字符串 ("Target"/"NonTarget") 或数值；统一编码为 int64 1/0。
    D-aux-channels   下载脚本保存 channel_names；旧缓存缺失时按 MOABB dataset METADATA 回退，
                     并显式告警（提醒用户重新生成缓存）。
    D-aux-t-align    MOABB P300 默认 tmin=0/tmax=1s，可能得到 T=257；统一裁到 256，不足补 0。
                     时间窗差异在 pretrain 脚本记录，不在此处静默重对齐。
"""

from __future__ import annotations

import warnings
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Sequence, Union

import numpy as np
import pandas as pd

from data.preprocess import canonical_channel_name

# 下载脚本约定的项目 8 导蒙太奇顺序
PROJECT_8_CHANNELS: tuple[str, ...] = ("Fz", "Cz", "P3", "Pz", "P4", "PO7", "PO8", "Oz")

# BI2014a 全量 16 导顺序（MOABB METADATA.sensors；下载时 channels=None 保持该顺序）
_BI2014A_16_CHANNELS: tuple[str, ...] = (
    "Fp1", "Fp2", "F5", "AFz", "F6", "T7", "Cz", "T8",
    "P7", "P3", "Pz", "P4", "P8", "O1", "Oz", "O2",
)

_KNOWN_CHANNELS: dict[str, tuple[str, ...]] = {
    "erpcore": PROJECT_8_CHANNELS,
    "bnci008": PROJECT_8_CHANNELS,
    "bi2014a": _BI2014A_16_CHANNELS,
}

_LABEL_MAP = {
    "target": 1,
    "non-target": 0,
    "nontarget": 0,
    "non_target": 0,
}


@dataclass
class AuxiliaryData:
    """单个辅助 P300 数据集的统一视图。"""

    X: np.ndarray  # (N, C, T) float32
    y: np.ndarray  # (N,) int64，1=Target，0=NonTarget
    metadata: pd.DataFrame
    channel_names: tuple[str, ...]
    dataset: str
    subject_ids: np.ndarray  # (N,) str，来自 metadata.subject（缺省用索引）
    channel_mask: Optional[np.ndarray] = None  # 相对 target_channels 的存在掩码

    @property
    def n_epochs(self) -> int:
        return int(self.X.shape[0])

    @property
    def n_channels(self) -> int:
        return int(self.X.shape[1])

    @property
    def n_times(self) -> int:
        return int(self.X.shape[2])


def _encode_y(y: np.ndarray) -> np.ndarray:
    """MOABB y → int64 {1=Target, 0=NonTarget}；未知标签显式报错。"""
    y = np.asarray(y)
    if y.dtype.kind in ("U", "O", "S"):
        encoded = np.zeros(len(y), dtype=np.int64)
        for i, value in enumerate(y):
            if isinstance(value, bytes):
                value = value.decode()
            label = str(value).strip().lower()
            if label not in _LABEL_MAP:
                raise ValueError(f"未知辅助域标签 {value!r}；只接受 Target/NonTarget。")
            encoded[i] = _LABEL_MAP[label]
        return encoded
    return y.astype(np.int64)


def _align_n_times(X: np.ndarray, n_times: int) -> np.ndarray:
    """统一时间点数：T>n_times 裁前段，T<n_times 尾部补 0。"""
    T = X.shape[2]
    if T == n_times:
        return X
    if T > n_times:
        return X[:, :, :n_times]
    out = np.zeros((X.shape[0], X.shape[1], n_times), dtype=X.dtype)
    out[:, :, :T] = X
    return out


def select_channels(
    X: np.ndarray,
    channel_names: Sequence[str],
    target_channels: Sequence[str],
    *,
    strict: bool = False,
) -> tuple[np.ndarray, tuple[str, ...], np.ndarray]:
    """把辅助数据裁剪/重排到 target_channels；返回 (X, names, mask)。"""
    X = np.asarray(X)
    present: dict[str, int] = {}
    for i, name in enumerate(channel_names):
        key = canonical_channel_name(name)
        if key in present:
            raise ValueError(f"通道重名：{channel_names[present[key]]!r} 与 {name!r}。")
        present[key] = i

    picks: list[int] = []
    mask = np.zeros(len(target_channels), dtype=bool)
    for j, target in enumerate(target_channels):
        idx = present.get(canonical_channel_name(target))
        if idx is not None:
            mask[j] = True
            picks.append(idx)
        elif strict:
            raise ValueError(
                f"辅助数据缺少目标通道 {target!r}；现有通道={list(channel_names)}。"
            )

    if not picks:
        raise ValueError(f"辅助数据与目标通道 {tuple(target_channels)} 无任何交集。")
    return X[:, picks, :], tuple(channel_names[i] for i in picks), mask


def load_auxiliary(
    name: str,
    cache_dir: Union[str, Path] = "experiments/cache",
    *,
    target_channels: Optional[Sequence[str]] = None,
    strict_channels: bool = False,
    n_times: int = 256,
) -> AuxiliaryData:
    """加载 download_datasets.py 保存的辅助数据缓存。"""
    cache_dir = Path(cache_dir)
    npz_path = cache_dir / f"{name}.npz"
    csv_path = cache_dir / f"{name}_metadata.csv"
    if not npz_path.exists():
        raise FileNotFoundError(
            f"{npz_path} 不存在。请先运行 experiments/download_datasets.py "
            f"--dataset {name} 下载并处理。"
        )

    with np.load(npz_path, allow_pickle=True) as z:
        X = np.asarray(z["X"], dtype=np.float32)
        y = _encode_y(z["y"])
        if "channel_names" in z:
            channel_names = tuple(str(c) for c in z["channel_names"])
        else:
            fallback = _KNOWN_CHANNELS.get(name)
            if fallback is None:
                raise ValueError(
                    f"{name}.npz 没有 channel_names 且无内置回退；请重新运行下载脚本。"
                )
            warnings.warn(
                f"{name}.npz 是旧缓存（无 channel_names），按内置通道顺序回退；"
                "建议重新运行 download_datasets.py 生成新缓存。",
                stacklevel=2,
            )
            channel_names = tuple(fallback)

    if len(y) != len(X):
        raise ValueError(f"缓存损坏：len(y)={len(y)} != len(X)={len(X)}。")
    if len(channel_names) != X.shape[1]:
        raise ValueError(
            f"缓存通道数不一致：channel_names={len(channel_names)} != X.shape[1]={X.shape[1]}。"
        )

    metadata = pd.read_csv(csv_path) if csv_path.exists() else pd.DataFrame()
    channel_mask = np.ones(len(channel_names), dtype=bool)

    if target_channels is not None:
        X, channel_names, channel_mask = select_channels(
            X, channel_names, target_channels, strict=strict_channels
        )

    X = _align_n_times(X, n_times).astype(np.float32, copy=False)

    if "subject" in metadata.columns:
        subject_ids = metadata["subject"].astype(str).to_numpy()
        if len(subject_ids) != len(X):
            warnings.warn(
                f"{name}_metadata.csv 的 subject 行数 {len(subject_ids)} 与 X 行数 {len(X)} 不一致，"
                "回退为索引 subject_id。",
                stacklevel=2,
            )
            subject_ids = np.arange(len(X), dtype=np.int64).astype(str)
    else:
        subject_ids = np.arange(len(X), dtype=np.int64).astype(str)

    return AuxiliaryData(
        X=X,
        y=y,
        metadata=metadata,
        channel_names=channel_names,
        dataset=name,
        subject_ids=subject_ids,
        channel_mask=channel_mask,
    )
