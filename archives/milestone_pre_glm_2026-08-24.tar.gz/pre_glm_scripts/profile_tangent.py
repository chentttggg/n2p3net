import os
import sys
import time

for name in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ.setdefault(name, "24")

sys.path.insert(0, r"D:\Temp\n2p3-net\src")
import numpy as np
from pyriemann.utils.base import invsqrtm, sqrtm
from pyriemann.utils.mean import mean_riemann
from pyriemann.utils.tangentspace import tangent_space

from baselines.riemann import _oas_covariances_vectorized

rng = np.random.default_rng(0)
# Generate SPD 6x6 matrices
A = rng.standard_normal((38000, 6, 6))
C = A @ A.transpose(0, 2, 1) / 6 + np.eye(6) * 0.5

t = time.perf_counter(); Cref = mean_riemann(C); print("mean_riemann", time.perf_counter()-t, flush=True)
t = time.perf_counter(); T = tangent_space(C, Cref, metric="riemann"); print("tangent_space", time.perf_counter()-t, flush=True)
print(Cref.shape, T.shape)


def riemann_logm_batched(X):
    w, Q = np.linalg.eigh(X)
    w = np.maximum(w, 1e-15)
    return Q @ (np.log(w)[..., None] * Q.transpose(0, 2, 1))

def tangent_batched(X, Cref):
    Cm12 = invsqrtm(Cref)
    S = Cm12 @ X @ Cm12
    L = riemann_logm_batched(S)
    n = X.shape[-1]
    idx = np.triu_indices(n)
    coeff = np.sqrt(2.0) * np.triu(np.ones((n, n)), 1) + np.eye(n)
    return coeff[idx] * L[:, idx[0], idx[1]]

t = time.perf_counter(); Cm12 = invsqrtm(Cref); S = Cm12 @ C @ Cm12; print("prep + S", time.perf_counter()-t, flush=True)
t = time.perf_counter(); L = riemann_logm_batched(S); print("batched logm", time.perf_counter()-t, flush=True)
t = time.perf_counter(); T2 = tangent_batched(C, Cref); print("batched total", time.perf_counter()-t, flush=True)
print("diff", np.max(np.abs(T - T2)), np.mean(np.abs(T - T2)), np.allclose(T, T2, atol=1e-8))
