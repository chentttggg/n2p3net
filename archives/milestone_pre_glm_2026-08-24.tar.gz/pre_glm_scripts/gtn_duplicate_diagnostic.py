import sys
from pathlib import Path

sys.path.insert(0, r"D:\Temp\n2p3-net\src")
from data.gtn import read_gtn_experiment, _nix_subject_ids
from data.preprocess import preprocess

root = Path(r"D:\Temp\n2p3-net\mne_data\MNE-P3-data")
targets = {"P3Numbers_20141124_m_14_002", "P3Numbers_20150126_f_14_001"}
for exp in sorted([d for d in root.iterdir() if d.is_dir() and d.name.startswith("Experiment")]):
    nix = list(exp.glob("*.nix"))
    if not nix:
        continue
    internal = _nix_subject_ids(nix[0])
    txts = {p.stem: p for p in (exp / "Data").glob("*.txt")} if (exp / "Data").exists() else {}
    matched = [i for i in internal if i in txts]
    if not matched:
        continue
    sid = matched[0]
    if sid in targets or exp.name in {"Experiment_456_P3_Numbers", "Experiment_627_P3_Numbers", "Experiment_660_P3_Numbers"}:
        try:
            g = read_gtn_experiment(exp)
            r = preprocess(g.raw, g.events, standard=("Fz", "Cz", "Pz"), sfreq=256.0, l_freq=0.1,
                           tmin=-0.2, tmax=0.8)
            d = g.events[r.event_indices, 2].astype(int)
            y = (d == g.thought_number).astype(int)
            print(exp.name, "sid=", sid, "epochs=", len(y), "thought=", g.thought_number, "dropped=", len(r.dropped))
        except Exception as ex:  # noqa: BLE001
            print(exp.name, "sid=", sid, "ERROR", type(ex).__name__, ex)
