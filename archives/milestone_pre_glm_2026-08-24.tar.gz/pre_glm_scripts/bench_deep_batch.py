from __future__ import annotations

import sys
import time

sys.path.insert(0, r"D:\Temp\n2p3-net\src")
import numpy as np
import torch

from baselines.deep import DeepBaseline, DeepConfig

rng = np.random.default_rng(0)
N = 38000
C, T = 3, 256
X = rng.standard_normal((N, C, T)).astype(np.float32)
y = rng.integers(0, 2, N).astype(np.int64)
device = torch.device("cuda")

for name in ("eegnet", "inception", "conformer"):
    for bs in (64, 256, 512):
        torch.cuda.empty_cache()
        clf = DeepBaseline(name, n_chans=C, n_times=T, sfreq=256.0,
                           config=DeepConfig(epochs=1, batch_size=bs), device=device)
        t = time.perf_counter()
        try:
            clf.fit(X, y)
            torch.cuda.synchronize()
            dt = time.perf_counter() - t
            print(name, "bs", bs, "fit1", round(dt, 3), "mem_mb", round(torch.cuda.max_memory_allocated()/1e6), flush=True)
        except Exception as e:  # noqa: BLE001
            print(name, "bs", bs, "ERR", type(e).__name__, e, flush=True)
            break
        # tiny predict
        t = time.perf_counter()
        clf.predict_logit(X[:1000])
        torch.cuda.synchronize()
        print("  predict1k", round(time.perf_counter()-t, 4), flush=True)
