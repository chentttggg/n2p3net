from pathlib import Path

p = Path(r"D:\Temp\n2p3-net\src\train\trainer.py")
s = p.read_text(encoding="utf-8")
old = "            if self.cfg.accum_steps > 1 and n_batches % self.cfg.accum_steps != 0:\n                self.optimizer.step()\n                self.model.component_window.clamp_tau0_()  # review v6 P1\n                self.optimizer.zero_grad(set_to_none=True)\n"
new = "            if self.cfg.accum_steps > 1 and n_batches % self.cfg.accum_steps != 0:\n                if self._accum_has_grad:\n                    self.optimizer.step()\n                    self.model.component_window.clamp_tau0_()  # review v6 P1\n                self.optimizer.zero_grad(set_to_none=True)\n                self._accum_has_grad = False\n"
if old not in s:
    print("not found")
else:
    s = s.replace(old, new)
    p.write_text(s, encoding="utf-8")
    print("patched")
