"""Micro-benchmark: sequential vs threads vs processes for xDAWN LOSO folds."""
from __future__ import annotations

import os
import sys
import time
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "n2p3-net" / "src"))
import numpy as np

from baselines.evaluate import loso_folds
from baselines.riemann import XdawnRiemann
from data.gtn import read_gtn_experiment
from data.preprocess import preprocess

_ROOT = Path(__file__).resolve().parent / "n2p3-net" / "mne_data" / "MNE-P3-data"
GTN_STANDARD = ("Fz", "Cz", "Pz")

_X = None
_Y = None


def _load(n_subjects: int = 24):
    exps = sorted([d for d in _ROOT.iterdir() if d.is_dir() and d.name.startswith("Experiment")])[:n_subjects]
    xs, ys, subs = [], [], []
    for exp in exps:
        g = read_gtn_experiment(exp)
        r = preprocess(g.raw, g.events, standard=GTN_STANDARD, sfreq=256.0, l_freq=0.1,
                       tmin=-0.2, tmax=0.8)
        d = g.events[r.event_indices, 2].astype(int)
        y = (d == g.thought_number).astype(int)
        if len(y) == 0:
            continue
        xs.append(r.data)
        ys.append(y)
        subs.extend([g.subject_id] * len(y))
    return np.concatenate(xs).astype(np.float32), np.concatenate(ys).astype(np.int64), np.array(subs)


def _fold(args):
    global _X, _Y
    train_mask, test_mask = args
    model = XdawnRiemann()
    model.fit(_X[train_mask], _Y[train_mask])
    return float(model.predict_logit(_X[test_mask]).mean())


def _init(x, y):
    global _X, _Y
    _X, _Y = x, y


def main():
    n = 60
    X, y, subs = _load(n)
    folds = loso_folds(subs)
    print(f"folds={len(folds)} X={X.shape}", flush=True)

    _init(X, y)
    t0 = time.time()
    for train, test in folds[:n]:
        _fold((train, test))
    print(f"sequential: {time.time()-t0:.2f}s", flush=True)

    t0 = time.time()
    with ThreadPoolExecutor(max_workers=8) as ex:
        list(ex.map(_fold, folds[:n]))
    print(f"threads(8): {time.time()-t0:.2f}s", flush=True)

    t0 = time.time()
    with ProcessPoolExecutor(max_workers=8, initializer=_init, initargs=(X, y)) as ex:
        list(ex.map(_fold, folds[:n]))
    print(f"processes(8): {time.time()-t0:.2f}s", flush=True)

    t0 = time.time()
    with ProcessPoolExecutor(max_workers=16, initializer=_init, initargs=(X, y)) as ex:
        list(ex.map(_fold, folds[:n]))
    print(f"processes(16): {time.time()-t0:.2f}s", flush=True)


if __name__ == "__main__":
    main()
