from __future__ import annotations

import os
import sys
import time
from pathlib import Path

for name in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ.setdefault(name, "16")

sys.path.insert(0, str(Path(__file__).resolve().parent / "n2p3-net" / "src"))
import numpy as np
from pyriemann.estimation import Covariances, Xdawn
from pyriemann.tangentspace import TangentSpace
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis

from baselines.evaluate import loso_folds
from baselines.riemann import XdawnRiemann
from data.gtn import read_gtn_experiment
from data.preprocess import preprocess


def oas_covariances_vec(X: np.ndarray) -> np.ndarray:
    """Vectorized OAS covariance for (N,C,T) data, replicating sklearn/pyriemann formula."""
    X = np.asarray(X, dtype=np.float64)
    N, C, T = X.shape
    Xc = X - X.mean(axis=2, keepdims=True)
    S = (Xc @ Xc.transpose(0, 2, 1)) / T
    alpha = (S * S).mean(axis=(1, 2))
    mu = np.einsum("nii->n", S) / C
    mu2 = mu * mu
    num = alpha + mu2
    den = (T + 1) * (alpha - mu2 / C)
    rho = np.where(den == 0, 1.0, np.minimum(num / np.where(den == 0, 1.0, den), 1.0))
    C_out = (1.0 - rho)[:, None, None] * S
    idx = np.arange(C)
    C_out[:, idx, idx] += rho[:, None] * mu[:, None]
    return C_out


def main():
    root = Path(__file__).resolve().parent / "n2p3-net" / "mne_data" / "MNE-P3-data"
    exps = sorted([d for d in root.iterdir() if d.is_dir() and d.name.startswith("Experiment")])[:30]
    xs, ys, subs = [], [], []
    for exp in exps:
        g = read_gtn_experiment(exp)
        r = preprocess(g.raw, g.events, standard=("Fz", "Cz", "Pz"), sfreq=256.0, l_freq=0.1,
                       tmin=-0.2, tmax=0.8)
        d = g.events[r.event_indices, 2].astype(int)
        y = (d == g.thought_number).astype(int)
        if len(y):
            xs.append(r.data)
            ys.append(y)
            subs.extend([g.subject_id] * len(y))
    X = np.concatenate(xs).astype(np.float32)
    y = np.concatenate(ys).astype(np.int64)
    subs = np.array(subs)
    train, test = loso_folds(subs)[-1]
    Xd = Xdawn(nfilter=4, estimator="oas").fit_transform(X[train].astype(np.float64), y[train].astype(int))

    t0 = time.time(); C1 = Covariances(estimator="oas").fit_transform(Xd); t1 = time.time() - t0
    t0 = time.time(); C2 = oas_covariances_vec(Xd); t2 = time.time() - t0
    print(f"pyriemann cov: {t1:.4f}s  vectorized: {t2:.4f}s  speedup {t1/t2:.1f}x")
    print("max abs diff", np.max(np.abs(C1 - C2)))
    print("mean abs diff", np.mean(np.abs(C1 - C2)))
    print("close all", np.allclose(C1, C2, atol=1e-10))

    t0 = time.time(); T1 = TangentSpace(metric="riemann").fit_transform(C1); t1 = time.time() - t0
    t0 = time.time(); T2 = TangentSpace(metric="riemann").fit_transform(C2); t2 = time.time() - t0
    print("tangent py vs vec data close", np.allclose(T1, T2, atol=1e-9))


if __name__ == "__main__":
    main()
