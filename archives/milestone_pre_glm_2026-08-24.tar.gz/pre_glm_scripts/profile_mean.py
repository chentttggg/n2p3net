import os
import sys
import time

for name in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ.setdefault(name, "24")

sys.path.insert(0, r"D:\Temp\n2p3-net\src")
import numpy as np
from scipy.linalg import sqrtm, inv, expm
from pyriemann.utils.base import invsqrtm
from pyriemann.utils.mean import mean_riemann

rng = np.random.default_rng(0)
A = rng.standard_normal((38000, 6, 6))
C = A @ A.transpose(0, 2, 1) / 6 + np.eye(6) * 0.5


def logm_batched(X):
    w, Q = np.linalg.eigh(X)
    w = np.maximum(w, 1e-15)
    return Q @ (np.log(w)[..., None] * Q.transpose(0, 2, 1))


def mean_riemann_batched(X, *, tol=10e-9, maxiter=50):
    n_mat, n, _ = X.shape
    M = X.mean(axis=0)
    nu = 1.0
    tau = np.finfo(np.float64).max
    n_iter = 0
    for _ in range(maxiter):
        n_iter += 1
        M12 = sqrtm(M)
        Mm12 = invsqrtm(M)
        J = logm_batched(Mm12 @ X @ Mm12).mean(axis=0)
        M = M12 @ expm(nu * J) @ M12
        crit = np.linalg.norm(J, ord="fro")
        h = nu * crit
        if h < tau:
            nu = 0.95 * nu
            tau = h
        else:
            nu = 0.5 * nu
        if crit <= tol or nu <= tol:
            break
    return M, n_iter


t = time.perf_counter(); R1 = mean_riemann(C); t1 = time.perf_counter()-t; print("pyriemann mean", t1, flush=True)
t = time.perf_counter(); R2, it = mean_riemann_batched(C); t2 = time.perf_counter()-t; print("batched mean", t2, "iter", it, flush=True)
print("diff", np.max(np.abs(R1-R2)), np.mean(np.abs(R1-R2)), np.allclose(R1, R2, atol=1e-9))
