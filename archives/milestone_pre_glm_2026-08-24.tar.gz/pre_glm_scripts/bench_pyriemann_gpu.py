import os
import sys
import time

sys.path.insert(0, r"D:\Temp\n2p3-net\src")
import numpy as np
import torch
from pyriemann.utils.covariance import covariances
from pyriemann.utils.mean import mean_riemann
from pyriemann.utils.tangentspace import tangent_space

rng = np.random.default_rng(0)
X = rng.standard_normal((38000, 6, 256)).astype(np.float64)
A = rng.standard_normal((38000, 6, 6))
C = A @ A.transpose(0, 2, 1) / 6 + np.eye(6) * 0.5

t = time.perf_counter(); C1 = covariances(X, estimator="oas"); print("cpu oas", time.perf_counter()-t, flush=True)
t = time.perf_counter(); R1 = mean_riemann(C); print("cpu mean", time.perf_counter()-t, flush=True)
t = time.perf_counter(); T1 = tangent_space(C, R1, metric="riemann"); print("cpu tangent", time.perf_counter()-t, flush=True)

Xt = torch.from_numpy(X).cuda()
Ct = torch.from_numpy(C).cuda()
# warmup
covariances(Xt, estimator="oas")
torch.cuda.synchronize()
t = time.perf_counter(); C2 = covariances(Xt, estimator="oas"); torch.cuda.synchronize(); print("gpu oas", time.perf_counter()-t, flush=True)
t = time.perf_counter(); R2 = mean_riemann(Ct); torch.cuda.synchronize(); print("gpu mean", time.perf_counter()-t, flush=True)
t = time.perf_counter(); T2 = tangent_space(Ct, R2, metric="riemann"); torch.cuda.synchronize(); print("gpu tangent", time.perf_counter()-t, flush=True)
print("mem", torch.cuda.memory_allocated()/1e6)
print("diff C", np.max(np.abs(C1-C2.cpu().numpy())))
print("diff T", np.max(np.abs(T1-T2.cpu().numpy())))
