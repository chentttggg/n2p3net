"""Benchmark xDAWN sequential runtime under different BLAS thread settings."""
from __future__ import annotations

import os
import sys
import time
from pathlib import Path

# Set before numpy/sklearn import if requested via env arg
for _name in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    if os.environ.get(_name):
        continue
    os.environ[_name] = "16"

sys.path.insert(0, str(Path(__file__).resolve().parent / "n2p3-net" / "src"))
import numpy as np

from baselines.evaluate import loso_folds
from baselines.riemann import XdawnRiemann
from data.gtn import read_gtn_experiment
from data.preprocess import preprocess

_ROOT = Path(__file__).resolve().parent / "n2p3-net" / "mne_data" / "MNE-P3-data"
GTN_STANDARD = ("Fz", "Cz", "Pz")


def load(n_subjects=30):
    exps = sorted([d for d in _ROOT.iterdir() if d.is_dir() and d.name.startswith("Experiment")])[:n_subjects]
    xs, ys, subs = [], [], []
    for exp in exps:
        g = read_gtn_experiment(exp)
        r = preprocess(g.raw, g.events, standard=GTN_STANDARD, sfreq=256.0, l_freq=0.1,
                       tmin=-0.2, tmax=0.8)
        d = g.events[r.event_indices, 2].astype(int)
        y = (d == g.thought_number).astype(int)
        if len(y):
            xs.append(r.data)
            ys.append(y)
            subs.extend([g.subject_id] * len(y))
    return np.concatenate(xs).astype(np.float32), np.concatenate(ys).astype(np.int64), np.array(subs)


def main():
    X, y, subs = load(30)
    folds = loso_folds(subs)
    t0 = time.time()
    for train, test in folds:
        m = XdawnRiemann()
        m.fit(X[train], y[train])
        m.predict_logit(X[test])
    print(f"xdawn folds={len(folds)} time={time.time()-t0:.2f}s", flush=True)


if __name__ == "__main__":
    main()
