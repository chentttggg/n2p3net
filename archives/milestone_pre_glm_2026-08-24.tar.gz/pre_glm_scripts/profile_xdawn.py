from __future__ import annotations

import os
import sys
import time
from pathlib import Path

for name in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ.setdefault(name, "16")

sys.path.insert(0, str(Path(__file__).resolve().parent / "n2p3-net" / "src"))
import numpy as np
from pyriemann.estimation import Covariances, Xdawn
from pyriemann.tangentspace import TangentSpace
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis

from baselines.evaluate import loso_folds
from baselines.riemann import XdawnRiemann
from data.gtn import read_gtn_experiment
from data.preprocess import preprocess

root = Path(__file__).resolve().parent / "n2p3-net" / "mne_data" / "MNE-P3-data"
exps = sorted([d for d in root.iterdir() if d.is_dir() and d.name.startswith("Experiment")])[:30]
xs, ys, subs = [], [], []
for exp in exps:
    g = read_gtn_experiment(exp)
    r = preprocess(g.raw, g.events, standard=("Fz", "Cz", "Pz"), sfreq=256.0, l_freq=0.1,
                   tmin=-0.2, tmax=0.8)
    d = g.events[r.event_indices, 2].astype(int)
    y = (d == g.thought_number).astype(int)
    if len(y):
        xs.append(r.data)
        ys.append(y)
        subs.extend([g.subject_id] * len(y))
X = np.concatenate(xs).astype(np.float32)
y = np.concatenate(ys).astype(np.int64)
subs = np.array(subs)
train, test = loso_folds(subs)[-1]

m = XdawnRiemann()
t = time.perf_counter(); Xd = m._as_double(X[train]); yt = np.asarray(y[train]).astype(int); print("asdouble", time.perf_counter() - t)
t = time.perf_counter(); m.xd_ = Xdawn(nfilter=4, estimator="oas", classes=None); Xd_f = m.xd_.fit_transform(Xd, yt); print("xdawn", time.perf_counter() - t)
t = time.perf_counter(); m.cov_ = Covariances(estimator="oas"); C = m.cov_.fit_transform(Xd_f); print("cov", time.perf_counter() - t)
t = time.perf_counter(); m.ts_ = TangentSpace(metric="riemann"); T = m.ts_.fit_transform(C); print("tangent", time.perf_counter() - t)
t = time.perf_counter(); m.lda_ = LinearDiscriminantAnalysis(); m.lda_.fit(T, yt); print("lda", time.perf_counter() - t)
t = time.perf_counter(); Xt = m._as_double(X[test]); Xdf = m.xd_.transform(Xt); C2 = m.cov_.transform(Xdf); T2 = m.ts_.transform(C2); z = m.lda_.decision_function(T2); print("predict", time.perf_counter() - t)
print("shapes", Xd.shape, Xd_f.shape, C.shape, T.shape, z.shape)
