﻿from __future__ import annotations
import os, sys, time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
for name in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ.setdefault(name, "16")
sys.path.insert(0, r"D:\Temp\n2p3-net\src")
from data.gtn import read_gtn_experiment
from data.preprocess import preprocess

ROOT = Path(r"D:\Temp\n2p3-net\mne_data\MNE-P3-data")
STD = ("Fz","Cz","Pz")

def load_one(exp):
    g = read_gtn_experiment(exp)
    r = preprocess(g.raw, g.events, standard=STD, sfreq=256.0, l_freq=0.1, tmin=-0.2, tmax=0.8)
    d = g.events[r.event_indices,2].astype(int)
    y = (d == g.thought_number).astype(int)
    return r.data, y, d, g.subject_id

def serial(exps):
    out=[]
    for e in exps:
        out.append(load_one(e))
    return out

def threaded(exps, n):
    out=[]
    with ThreadPoolExecutor(max_workers=n) as ex:
        futs=[ex.submit(load_one,e) for e in exps]
        for f in as_completed(futs):
            out.append(f.result())
    return out

if __name__ == "__main__":
    exps=sorted([d for d in ROOT.iterdir() if d.is_dir() and d.name.startswith("Experiment")])[:20]
    for mode,fn in [("serial",lambda:serial(exps)),("threads4",lambda:threaded(exps,4)),("threads8",lambda:threaded(exps,8))]:
        t=time.perf_counter(); out=fn(); dt=time.perf_counter()-t
        print(mode, dt, sum(len(x[0]) for x in out))
