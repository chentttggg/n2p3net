import os
import sys
import time

sys.path.insert(0, r"D:\Temp\n2p3-net\src")
import numpy as np
import torch
from pyriemann.utils.mean import mean_riemann

rng = np.random.default_rng(0)
A = rng.standard_normal((38000, 6, 6))
C = A @ A.transpose(0, 2, 1) / 6 + np.eye(6) * 0.5


def sqrtm_inv_sqrtm_torch(M):
    w, Q = torch.linalg.eigh(M)
    w = torch.clamp(w, min=1e-15)
    M12 = Q @ (torch.sqrt(w)[None, :] * Q.transpose(0, 1))
    Mm12 = Q @ ((1.0 / torch.sqrt(w))[None, :] * Q.transpose(0, 1))
    return M12, Mm12


def expm_torch(J, nu):
    w, Q = torch.linalg.eigh(nu * J)
    return Q @ (torch.exp(w)[None, :] * Q.transpose(0, 1))


def mean_torch(X, tol=10e-9, maxiter=50):
    n, c, _ = X.shape
    M = X.mean(dim=0)
    nu = 1.0
    tau = float(np.finfo(np.float64).max)
    for _ in range(maxiter):
        M12, Mm12 = sqrtm_inv_sqrtm_torch(M)
        S = Mm12 @ X @ Mm12
        w, Q = torch.linalg.eigh(S)
        w = torch.clamp(w, min=1e-15)
        L = Q @ (torch.log(w)[..., None] * Q.transpose(1, 2))
        J = L.mean(dim=0)
        M = M12 @ expm_torch(J, nu) @ M12
        crit = torch.linalg.matrix_norm(J, ord="fro").item()
        h = nu * crit
        if h < tau:
            nu = 0.95 * nu
            tau = h
        else:
            nu = 0.5 * nu
        if crit <= tol or nu <= tol:
            break
    return M


t = time.perf_counter(); R1 = mean_riemann(C); print("cpu", time.perf_counter()-t, flush=True)
for dtype in (torch.float64, torch.float32):
    Ct = torch.from_numpy(C).cuda().to(dtype)
    for _ in range(1):
        mean_torch(Ct)
    torch.cuda.synchronize()
    t = time.perf_counter()
    for _ in range(2):
        Rt = mean_torch(Ct)
    torch.cuda.synchronize()
    print("gpu", dtype, (time.perf_counter()-t)/2, flush=True)
Rt64 = torch.from_numpy(C).cuda().to(torch.float64)
Rt = mean_torch(Rt64)
print("diff", np.max(np.abs(R1 - Rt.cpu().numpy())))
