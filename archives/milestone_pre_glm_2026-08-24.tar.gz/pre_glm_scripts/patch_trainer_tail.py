from pathlib import Path

p = Path(r"D:\Temp\n2p3-net\src\train\trainer.py")
s = p.read_text(encoding="utf-8")
old = """              # 尾部梯度累积：n_batches % accum_steps ≠ 0 时补一次 step（review P3，防尾部梯度丢失）
              if self.cfg.accum_steps > 1 and n_batches % self.cfg.accum_steps != 0:
                  self.optimizer.step()
                  self.model.component_window.clamp_tau0_()  # review v6 P1
                  self.optimizer.zero_grad(set_to_none=True)
"""
new = """              # 尾部梯度累积：n_batches % accum_steps ≠ 0 时补一次 step（review P3，防尾部梯度丢失）
              if self.cfg.accum_steps > 1 and n_batches % self.cfg.accum_steps != 0:
                  if self._accum_has_grad:
                      self.optimizer.step()
                      self.model.component_window.clamp_tau0_()  # review v6 P1
                  self.optimizer.zero_grad(set_to_none=True)
                  self._accum_has_grad = False
"""
if old not in s:
    print("old not found")
else:
    s = s.replace(old, new)
    p.write_text(s, encoding="utf-8")
    print("patched")
