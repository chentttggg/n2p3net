import os
import sys
import time

for name in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ.setdefault(name, "24")

sys.path.insert(0, r"D:\Temp\n2p3-net\src")
import numpy as np
from pyriemann.estimation import Xdawn
from pyriemann.tangentspace import TangentSpace
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis

from baselines.riemann import _oas_covariances_vectorized

rng = np.random.default_rng(0)
X = rng.standard_normal((38000, 3, 256)).astype(np.float64)
y = rng.integers(0, 2, 38000).astype(np.int64)

t = time.perf_counter(); xd = Xdawn(nfilter=4, estimator="oas"); Xd = xd.fit_transform(X, y); print("xdawn", time.perf_counter()-t, flush=True)
t = time.perf_counter(); C = _oas_covariances_vectorized(Xd); print("oas_vec", time.perf_counter()-t, flush=True)
t = time.perf_counter(); ts = TangentSpace(metric="riemann"); T = ts.fit_transform(C); print("tangent", time.perf_counter()-t, flush=True)
t = time.perf_counter(); lda = LinearDiscriminantAnalysis(); lda.fit(T, y); print("lda", time.perf_counter()-t, flush=True)
print("shapes", Xd.shape, C.shape, T.shape)
