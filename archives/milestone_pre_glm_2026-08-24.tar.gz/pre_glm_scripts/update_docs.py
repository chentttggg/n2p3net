from pathlib import Path

root = Path(r"D:\Temp\n2p3-net\doc")

# ---------- blueprint ----------
bp = root / "blueprint.md"
s = bp.read_text(encoding="utf-8")
s = s.replace(
    "> 版本：v3（吸收 review v3：修正 P0①R 矩阵外积方向、P0②正弦编码频率封顶、P1 四项、P2 小坑）。",
    "> 版本：v4（吸收 review v6 Phase 2 诊断：默认 Δτ 读出改为 attention_direct，P3b Δτ 放宽到\n> [−50,150]，新增自监督 jitter 一致性 L_jit；分类监督仍不直接标定 τ 的 ms 尺度）。",
)
s = s.replace(
    "       对每个成分 c：先估计潜伏期 τ_c = τ0_c + Δτ_c（τ0_c 数据驱动初始化，Δτ_c = MLP(global_pool(Z'))\n       经 tanh 缩放），再生成不对称高斯窗（D9）：",
    "       对每个成分 c：先估计潜伏期 τ_c = τ0_c + Δτ_c（τ0_c 数据驱动初始化；Δτ_c 由\n       dtau_readout 估计，默认 attention_direct），再生成不对称高斯窗（D9）：",
)
s = s.replace(
    "       因果反转（D8）：τ 是 A 的「生成参数」而非「事后统计量」，被分类直接监督。",
    "       因果反转（D8）：τ 是 A 的「生成参数」而非「事后统计量」，被分类监督；\n       但 review v6 实测分类饱和不保证 τ 被标定到物理 ms，故增加 L_jit 尺度锚定（§8）。",
)
s = s.replace(
    "       **Δτ 缩放界不对称（防 P3a/P3b 互换，v3 P1）**：P3a 只允许前移 Δτ∈[−30,0]ms、P3b 只允许\n       后移 Δτ∈[0,30]ms、N2 收窄 Δτ∈[−30,30]ms。理由：P3a/P3b 的 τ0 仅差 ~50ms，若两者对称\n       漂移 ±50ms 可完全互换位置，「位置寻址天然防坍缩」（E7）对这一对不成立，H_P3a 会冗余。",
    "       **Δτ 界不对称（v4 修订）**：N2 Δτ∈[−30,30]ms、P3a Δτ∈[−30,0]ms（只前移）；\n       P3b 放宽到 Δτ∈[−50,150]ms，覆盖真实 P3b 300–500ms。P3a 上界 ≤300ms、\n       P3b 下界 ≥300ms，保留防互换边界。",
)
s = s.replace(
    "       **global_pool 豁免说明（v3 P1）**：Δτ 经 global_pool(Z') 估计，功能上豁免 E5（读出路径\n       H_c=ΣA·Z' 未池化、保时间分辨率），但平均池化洗平时间信息会压低 τ 定位上限——Phase 2 的\n       MAE<40ms 诊断若失败，须先排除此摘要瓶颈（可换 attention-pool 或首 token 读出）再归因 PCW 机制。",
    "       **Δτ 读出（v4 默认 attention_direct）**：逐成分 query attention 的 soft-argmax 时间质心\n       t_attn 经 tanh 软映射直接生成 Δτ；global_pool 只作消融。global_pool 的 E5 豁免\n       被 review v6 实测推翻（它会洗平时间位置信息）。",
)
bp.write_text(s, encoding="utf-8")

# ---------- constitution ----------
c = root / "constitution.md"
s = c.read_text(encoding="utf-8")
s = s.replace(
    "> 版本：v3（新增 P9/E9/D9：辅助 P300 数据只预训练/域对齐，GTN 独占分类头与验收；详见 doc/transfer_policy.md）。",
    "> 版本：v4（新增 E10：分类饱和不保证 τ 的物理 ms 尺度，默认用自监督 jitter 一致性 L_jit 锚定；\n> 并修订 E7/blueprint：P3b Δτ 放宽到 [−50,150]ms、默认读出 attention_direct）。",
)
s = s.replace(
    "E7 成分窗须防坍缩（根治）。free attention 的多查询共享 1-bit 监督会坍缩（DETR 系失败模式）。\n    参数化成分窗以「位置寻址」替代「内容寻址」——不同成分先验中心 τ0 不同，位置天然区分，\n    无需 JSD 散度；只保留进头/进损失的成分（N2/P3a/P3b）。",
    "E7 成分窗须防坍缩（根治，v4 修订）。free attention 的多查询共享 1-bit 监督会坍缩（DETR 系\n    失败模式）。参数化成分窗以「位置寻址」替代「内容寻址」——不同成分先验中心 τ0 不同，\n    位置天然区分，无需 JSD 散度；只保留进头/进损失的成分（N2/P3a/P3b）。P3b 的 Δτ 界\n    放宽为 [−50,150]ms，以覆盖真实 P3b 300–500ms；P3a 仍只前移 [−30,0]ms，保留下界不重叠。",
)
s = s.replace(
    "E9 辅助预训练权重只是初始化或对齐信号，不是成品。即使使用辅助 P300 预训练，也必须保存",
    "E9 辅助预训练权重只是初始化或对齐信号，不是成品。即使使用辅助 P300 预训练，也必须保存",
)
# Insert E10 after E9 block; E9 text spans 3 lines ending "（P9 / transfer_policy.md）。"
s = s.replace(
    "     checkpoint、显式记录层加载/冻结映射，并在每个 GTN fold 完成微调后才能进入主评估；\n    辅助域单独精度不得作为主任务验收指标（P9 / transfer_policy.md）。",
    "     checkpoint、显式记录层加载/冻结映射，并在每个 GTN fold 完成微调后才能进入主评估；\n    辅助域单独精度不得作为主任务验收指标（P9 / transfer_policy.md）。\n\nE10 分类饱和不等于潜伏期已标定。review v6 合成诊断实测：分类 AUC 可接近 1.0，但 τ 仍\n    可能不随真实 latency jitter 协变。因此默认训练目标必须包含自监督 jitter 一致性\n    L_jit = mean((τ(x_shift)−τ(x)−shift_ms)²)/scale²，为 τ 提供物理 ms 尺度锚点；\n    该损失不使用任何真实峰值/潜伏期标签，不违反 E3。默认 λ_jit=0.05、jitter ±40ms。",
)
s = s.replace(
    "- v3（2026-08-21）：新增 P9/E9/D9。理由：明确「其他 P300 数据只做预训练或域对齐，最终每个\n    fold 仍在 GTN 上微调；分类头与评估协议只由 GTN 决定」的硬边界，防止辅助域污染猜数字情景。\n    影响：blueprint Stage 4、roadmap Phase 3、新增 doc/transfer_policy.md。",
    "- v3（2026-08-21）：新增 P9/E9/D9。理由：明确「其他 P300 数据只做预训练或域对齐，最终每个\n    fold 仍在 GTN 上微调；分类头与评估协议只由 GTN 决定」的硬边界，防止辅助域污染猜数字情景。\n    影响：blueprint Stage 4、roadmap Phase 3、新增 doc/transfer_policy.md。\n- v4（2026-08-21）：新增 E10 并修订 E7 落地口径。理由：合成诊断显示分类饱和不保证 τ 被标定，\n    global_pool 与窄 P3b Δτ 界分别造成信息洗平和结构饱和；默认改为 attention_direct + L_jit，\n    P3b Δτ=[−50,150]ms。影响：component_window / n2p3net / trainer / blueprint §4/§8。",
)
c.write_text(s, encoding="utf-8")

print("docs updated")
