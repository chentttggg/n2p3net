import os
import sys
import time

sys.path.insert(0, r"D:\Temp\n2p3-net\src")
import numpy as np
import torch

rng = np.random.default_rng(0)
A = rng.standard_normal((38000, 6, 6))
C = A @ A.transpose(0, 2, 1) / 6 + np.eye(6) * 0.5
R = np.mean(C, axis=0)
# use pyriemann invsqrtm for exact reference
from pyriemann.utils.base import invsqrtm
Cm12 = invsqrtm(R)
S = Cm12 @ C @ Cm12


def tangent_numpy(S):
    w, Q = np.linalg.eigh(S)
    w = np.maximum(w, 1e-15)
    L = Q @ (np.log(w)[..., None] * Q.transpose(0, 2, 1))
    n = S.shape[-1]
    idx = np.triu_indices(n)
    coeff = np.sqrt(2.0) * np.triu(np.ones((n, n)), 1) + np.eye(n)
    return coeff[idx] * L[:, idx[0], idx[1]]


def tangent_torch(S):
    w, Q = torch.linalg.eigh(S)
    w = torch.clamp(w, min=1e-15)
    L = Q @ (torch.log(w)[..., None] * Q.transpose(1, 2))
    n = S.shape[-1]
    idx = torch.triu_indices(n, n, device=S.device)
    coeff = torch.sqrt(torch.tensor(2.0, device=S.device)) * torch.triu(torch.ones((n, n), device=S.device), 1) + torch.eye(n, device=S.device)
    return coeff[idx[0], idx[1]] * L[:, idx[0], idx[1]]


t = time.perf_counter()
for _ in range(3):
    Tn = tangent_numpy(S)
print("cpu tangent", (time.perf_counter() - t) / 3, flush=True)

for dtype in (torch.float64, torch.float32):
    St = torch.from_numpy(S).cuda().to(dtype)
    for _ in range(2):
        tangent_torch(St)
    torch.cuda.synchronize()
    t = time.perf_counter()
    for _ in range(3):
        Tt = tangent_torch(St)
    torch.cuda.synchronize()
    print("gpu tangent", dtype, (time.perf_counter() - t) / 3, flush=True)

Tt64 = torch.from_numpy(S).cuda().to(torch.float64)
Tt = tangent_torch(Tt64)
print("diff", np.max(np.abs(Tn - Tt.cpu().numpy())))
