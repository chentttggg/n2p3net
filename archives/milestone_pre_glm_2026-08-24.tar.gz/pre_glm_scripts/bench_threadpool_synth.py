from __future__ import annotations

import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor

blas = os.environ.get("N2P3_BLAS_THREADS", "2")
for name in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ.setdefault(name, blas)

sys.path.insert(0, r"D:\Temp\n2p3-net\src")
import numpy as np

from baselines.riemann import XdawnRiemann

rng = np.random.default_rng(0)
N = 12000
X = rng.standard_normal((N, 3, 256)).astype(np.float32)
y = rng.integers(0, 2, N).astype(np.int64)
folds = []
for i in range(12):
    te = np.zeros(N, dtype=bool); te[i * 1000:(i + 1) * 1000] = True
    folds.append((~te, te))

def run_fold(masks):
    tr, te = masks
    m = XdawnRiemann()
    m.fit(X[tr], y[tr])
    return float(m.predict_logit(X[te]).mean())

t = time.perf_counter()
for masks in folds:
    run_fold(masks)
print("sequential", round(time.perf_counter() - t, 3), flush=True)

for workers in (2, 4, 6, 8):
    t = time.perf_counter()
    with ThreadPoolExecutor(max_workers=workers) as ex:
        list(ex.map(run_fold, folds))
    print(f"threads {workers}", round(time.perf_counter() - t, 3), flush=True)
