import os
import sys
import time

sys.path.insert(0, r"D:\Temp\n2p3-net\src")
import numpy as np
import torch

rng = np.random.default_rng(0)
X = rng.standard_normal((38000, 6, 256)).astype(np.float64)


def oas_numpy(X):
    n, c, t = X.shape
    Xc = X - X.mean(axis=2, keepdims=True)
    S = Xc @ Xc.transpose(0, 2, 1) / t
    alpha = (S * S).mean(axis=(1, 2))
    mu = np.einsum("nii->n", S) / c
    mu2 = mu * mu
    num = alpha + mu2
    den = (t + 1) * (alpha - mu2 / c)
    rho = np.where(den == 0, 1.0, np.minimum(num / np.where(den == 0, 1.0, den), 1.0))
    out = (1 - rho)[:, None, None] * S
    idx = np.arange(c)
    out[:, idx, idx] += rho[:, None] * mu[:, None]
    return out


def oas_torch(X):
    n, c, t = X.shape
    Xc = X - X.mean(dim=2, keepdim=True)
    S = Xc @ Xc.transpose(1, 2) / t
    alpha = (S * S).mean(dim=(1, 2))
    mu = torch.einsum("nii->n", S) / c
    mu2 = mu * mu
    num = alpha + mu2
    den = (t + 1) * (alpha - mu2 / c)
    rho = torch.where(den == 0, torch.ones_like(den), torch.minimum(num / torch.where(den == 0, torch.ones_like(den), den), torch.ones_like(den)))
    out = (1 - rho)[:, None, None] * S
    idx = torch.arange(c, device=X.device)
    out[:, idx, idx] += rho[:, None] * mu[:, None]
    return out


for dtype in (torch.float64, torch.float32):
    Xt = torch.from_numpy(X).cuda().to(dtype)
    # warmup
    for _ in range(2):
        C = oas_torch(Xt)
    torch.cuda.synchronize()
    t = time.perf_counter()
    for _ in range(3):
        C = oas_torch(Xt)
    torch.cuda.synchronize()
    print(dtype, "gpu oas", (time.perf_counter() - t) / 3, "mem", torch.cuda.memory_allocated() / 1e6, flush=True)

t = time.perf_counter()
for _ in range(3):
    Cn = oas_numpy(X)
print("numpy oas", (time.perf_counter() - t) / 3, flush=True)
print("diff f64", (C.cpu().double().numpy() - Cn).__abs__().max() if C.dtype == torch.float64 else "n/a")
