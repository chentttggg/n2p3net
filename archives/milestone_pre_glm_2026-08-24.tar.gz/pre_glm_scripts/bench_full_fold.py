import os
import sys
import time

for name in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ.setdefault(name, "24")

sys.path.insert(0, r"D:\Temp\n2p3-net\src")
import numpy as np

from baselines.riemann import XdawnRiemann

rng = np.random.default_rng(0)
X = rng.standard_normal((38000, 3, 256)).astype(np.float32)
y = rng.integers(0, 2, 38000).astype(np.int64)
m = XdawnRiemann()
t = time.perf_counter()
m.fit(X, y)
print("fit", time.perf_counter() - t, flush=True)
t = time.perf_counter()
m.predict_logit(X[:1000])
print("predict", time.perf_counter() - t, flush=True)
