from __future__ import annotations

import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

blas = os.environ.get("N2P3_BLAS_THREADS", "2")
for name in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ.setdefault(name, blas)

sys.path.insert(0, r"D:\Temp\n2p3-net\src")
import numpy as np

from baselines.evaluate import loso_folds
from baselines.riemann import XdawnRiemann
from data.gtn import read_gtn_experiment
from data.preprocess import preprocess

root = Path("mne_data/MNE-P3-data")
exps = sorted([d for d in root.iterdir() if d.is_dir() and d.name.startswith("Experiment")])[:12]
xs, ys, ss = [], [], []
for exp in exps:
    g = read_gtn_experiment(exp)
    r = preprocess(g.raw, g.events, standard=("Fz", "Cz", "Pz"), sfreq=256.0, l_freq=0.1,
                   tmin=-0.2, tmax=0.8)
    d = g.events[r.event_indices, 2].astype(int)
    y = (d == g.thought_number).astype(int)
    if len(y):
        xs.append(r.data); ys.append(y); ss.extend([g.subject_id] * len(y))
X = np.concatenate(xs).astype(np.float32)
y = np.concatenate(ys).astype(np.int64)
subs = np.array(ss)
folds = loso_folds(subs)
G_X, G_Y = X, y

def run_fold(masks):
    tr, te = masks
    m = XdawnRiemann()
    m.fit(G_X[tr], G_Y[tr])
    return float(m.predict_logit(G_X[te]).mean())

t = time.perf_counter()
for masks in folds:
    run_fold(masks)
print("sequential", round(time.perf_counter() - t, 3), "folds", len(folds), "threads", blas, flush=True)

for workers in (4, 6, 8):
    t = time.perf_counter()
    with ThreadPoolExecutor(max_workers=workers) as ex:
        list(ex.map(run_fold, folds))
    print(f"threads {workers}", round(time.perf_counter() - t, 3), flush=True)
