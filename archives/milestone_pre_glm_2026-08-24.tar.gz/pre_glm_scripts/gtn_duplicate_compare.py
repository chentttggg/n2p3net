import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, r"D:\Temp\n2p3-net\src")
from data.gtn import read_gtn_experiment

root = Path(r"D:\Temp\n2p3-net\mne_data\MNE-P3-data")
pairs = [
    ("Experiment_530_P3_Numbers", "Experiment_531_P3_Numbers"),
    ("Experiment_643_P3_Numbers", "Experiment_644_P3_Numbers"),
]
for a, b in pairs:
    ga = read_gtn_experiment(root / a)
    gb = read_gtn_experiment(root / b)
    ea, eb = ga.raw.get_data(), gb.raw.get_data()
    print(a, b)
    print("  shape", ea.shape, eb.shape)
    print("  raw equal", np.array_equal(ea, eb), "max diff", np.max(np.abs(ea - eb)))
    print("  events equal", np.array_equal(ga.events, gb.events))
    print("  n_times", ga.raw.n_times, gb.raw.n_times, "thought", ga.thought_number, gb.thought_number)
