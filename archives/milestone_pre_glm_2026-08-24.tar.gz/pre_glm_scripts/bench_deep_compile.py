import sys
import time

sys.path.insert(0, r"D:\Temp\n2p3-net\src")
import numpy as np
import torch

from baselines.deep import DeepBaseline, DeepConfig

rng = np.random.default_rng(0)
N, C, T = 38000, 3, 256
X = rng.standard_normal((N, C, T)).astype(np.float32)
y = rng.integers(0, 2, N).astype(np.int64)
device = torch.device("cuda")

for name in ("eegnet", "inception", "conformer"):
    for compile_model in (False, True):
        torch.cuda.empty_cache()
        clf = DeepBaseline(name, n_chans=C, n_times=T, sfreq=256.0,
                           config=DeepConfig(epochs=1, batch_size=512), device=device)
        # warmup model creation and input upload once to isolate compile
        clf.fit(X[:2000], y[:2000]) if False else None
        # monkey-patch _make_model for compile
        orig = clf._make_model
        if compile_model:
            clf._make_model = lambda: torch.compile(orig(), dynamic=False)
        t = time.perf_counter()
        try:
            clf.fit(X, y)
            torch.cuda.synchronize()
            print(name, "compile" if compile_model else "eager", "fit1", round(time.perf_counter()-t, 3), flush=True)
        except Exception as e:  # noqa: BLE001
            print(name, "compile" if compile_model else "eager", "ERR", type(e).__name__, e, flush=True)
