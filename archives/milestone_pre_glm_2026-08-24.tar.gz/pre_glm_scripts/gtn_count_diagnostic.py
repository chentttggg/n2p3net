import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, r"D:\Temp\n2p3-net\src")
from data.gtn import _nix_subject_ids

root = Path(r"D:\Temp\n2p3-net\mne_data\MNE-P3-data")
exps = sorted([d for d in root.iterdir() if d.is_dir() and d.name.startswith("Experiment")])
ids = []
no_nix = []
no_txt = []
multi = []
for e in exps:
    nix = list(e.glob("*.nix"))
    if not nix:
        no_nix.append(e.name)
        continue
    try:
        internal = _nix_subject_ids(nix[0])
    except Exception as ex:  # noqa: BLE001
        no_nix.append(f"{e.name}: {type(ex).__name__}: {ex}")
        continue
    data_dir = e / "Data"
    txts = {p.stem: p for p in data_dir.glob("*.txt")} if data_dir.exists() else {}
    matched = [i for i in internal if i in txts]
    if not matched:
        no_txt.append((e.name, internal, list(txts)))
        continue
    ids.extend(matched)
    if len(matched) > 1:
        multi.append((e.name, matched))

dup = [(k, v) for k, v in Counter(ids).items() if v > 1]
print("dirs", len(exps), "ids", len(ids), "unique", len(set(ids)))
print("no_nix_or_unreadable", no_nix)
print("no_txt", no_txt)
print("multi_internal", multi)
print("duplicate_ids", dup)
