import sys
sys.path.insert(0, r"D:\Temp\n2p3-net\src")
from baselines.deep import DeepBaseline

for name in ("eegnet", "inception", "conformer"):
    clf = DeepBaseline(name, n_chans=3, n_times=256, sfreq=256.0)
    model = clf._make_model()
    print(name, sum(p.numel() for p in model.parameters()))
