import sys
import time
from concurrent.futures import ThreadPoolExecutor

sys.path.insert(0, r"D:\Temp\n2p3-net\src")
import numpy as np
import torch

from baselines.deep import DeepBaseline, DeepConfig

rng = np.random.default_rng(0)
N, C, T = 12000, 3, 256
X = rng.standard_normal((N, C, T)).astype(np.float32)
y = rng.integers(0, 2, N).astype(np.int64)
device = torch.device("cuda")
folds = []
for i in range(4):
    te = np.zeros(N, dtype=bool)
    te[i * 1000:(i + 1) * 1000] = True
    folds.append((~te, te))

def run_one(masks):
    tr, te = masks
    clf = DeepBaseline("eegnet", n_chans=C, n_times=T, sfreq=256.0,
                       config=DeepConfig(epochs=1, batch_size=512), device=device)
    clf.fit(X[tr], y[tr])
    return float(clf.predict_logit(X[te]).mean())

t = time.perf_counter()
for f in folds:
    run_one(f)
torch.cuda.synchronize()
print("sequential", round(time.perf_counter() - t, 3), flush=True)

for workers in (2, 3, 4):
    torch.cuda.empty_cache()
    t = time.perf_counter()
    with ThreadPoolExecutor(max_workers=workers) as ex:
        list(ex.map(run_one, folds))
    torch.cuda.synchronize()
    print("threads", workers, round(time.perf_counter() - t, 3), flush=True)
