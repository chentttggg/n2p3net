from pathlib import Path

import numpy as np
import pandas as pd

out = Path(r"D:\Temp\aux_smoke")
out.mkdir(exist_ok=True)
rng = np.random.default_rng(0)
X = rng.standard_normal((40, 3, 256)).astype(np.float32)
y = np.array(["Target", "NonTarget"] * 20, dtype=object)
np.savez(out / "bnci008.npz", X=X, y=y, channel_names=np.array(["Fz", "Cz", "Pz"], dtype=object))
pd.DataFrame({"subject": np.repeat(np.arange(1, 5), 10)}).to_csv(out / "bnci008_metadata.csv", index=False)
print(out)
