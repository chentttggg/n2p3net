import sys
import torch

sys.path.insert(0, r"D:\Temp\n2p3-net\src")
from torch.utils.data import DataLoader, TensorDataset

from models.n2p3net import N2P3Net
from train.trainer import Trainer, TrainerConfig

torch.manual_seed(0)
model = N2P3Net()
cfg = TrainerConfig(
    augment=False,
    lambda_amp=0.0,
    lambda_jit=0.0,
    lambda2=0.0,
    lambda3=0.0,
    epochs=1,
    batch_size=1,
    accum_steps=2,
)
tr = Trainer(model, cfg, device=torch.device("cpu"))
w0 = model.tokenizer.pointwise.weight.detach().clone()

# batch 1: GTN (has gradient), batch 2: all-aux (zero loss)
X1 = torch.randn(1, 8, 128)
y1 = torch.tensor([[0.0]])
d1 = torch.tensor([0])
X2 = torch.randn(1, 8, 128)
y2 = torch.tensor([[1.0]])
d2 = torch.tensor([1])

loader = DataLoader(
    [
        (X1, y1, d1),
        (X2, y2, d2),
    ],
    batch_size=1,
)
tr.fit(loader)
print("weights_changed", not torch.allclose(w0, model.tokenizer.pointwise.weight))
