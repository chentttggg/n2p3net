import os
import sys
import time

for name in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ.setdefault(name, "24")

sys.path.insert(0, r"D:\Temp\n2p3-net\src")
import numpy as np
from pyriemann.utils.covariance import covariances
from pyriemann.estimation import Xdawn

rng = np.random.default_rng(0)
X = rng.standard_normal((38000, 3, 256))
y = rng.integers(0, 2, 38000).astype(int)

t = time.perf_counter(); tmp = X.transpose((1,2,0)); print("transpose", time.perf_counter()-t, flush=True)
t = time.perf_counter(); Cx = covariances(tmp.reshape(3, 256*38000), estimator="oas"); print("Cx oas", time.perf_counter()-t, flush=True)

classes = np.unique(y)
for c in classes:
    t = time.perf_counter(); P = np.mean(X[y==c], axis=0); print("P mean", c, time.perf_counter()-t, flush=True)
    t = time.perf_counter(); C = covariances(P, estimator="oas"); print("C proto oas", c, time.perf_counter()-t, flush=True)
    t = time.perf_counter(); from scipy.linalg import eigh; evals,evecs=eigh(C,Cx); print("eigh", c, time.perf_counter()-t, flush=True)
    t = time.perf_counter(); evecs=evecs[:,np.argsort(evals)[::-1]]; print("sort", time.perf_counter()-t, flush=True)
    t = time.perf_counter(); evecs /= np.apply_along_axis(np.linalg.norm,0,evecs); print("norm", time.perf_counter()-t, flush=True)
    V=evecs
    t = time.perf_counter(); A=np.linalg.pinv(V.T); print("pinv", time.perf_counter()-t, flush=True)
