from __future__ import annotations

import os
import sys
import time
from pathlib import Path

for name in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ.setdefault(name, "24")

sys.path.insert(0, r"D:\Temp\n2p3-net\src")
import numpy as np
from pyriemann.estimation import Xdawn
from pyriemann.utils.base import invsqrtm
from pyriemann.utils.mean import mean_riemann
from pyriemann.utils.tangentspace import upper
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis

from baselines.evaluate import evaluate, loso_folds
from baselines.riemann import _oas_covariances_vectorized, XdawnRiemann
from data.gtn import read_gtn_experiment
from data.preprocess import preprocess


def logm_batched(X):
    w, Q = np.linalg.eigh(X)
    w = np.maximum(w, 1e-15)
    return Q @ (np.log(w)[..., None] * Q.transpose(0, 2, 1))


def tangent_euclid(X, Cref):
    Cm12 = invsqrtm(Cref)
    L = logm_batched(Cm12 @ X @ Cm12)
    return upper(L)


class XdawnRiemannEuclid(XdawnRiemann):
    def fit(self, X, y):
        X = self._as_double(X)
        y = np.asarray(y).astype(int)
        self.xd_ = Xdawn(nfilter=self.nfilter, estimator=self.estimator, classes=self.classes)
        Xd = self.xd_.fit_transform(X, y)
        C = _oas_covariances_vectorized(Xd)
        self._cov_is_oas = self.estimator == "oas"
        self.cov_ = None
        self.ref_ = C.mean(axis=0)
        T = tangent_euclid(C, self.ref_)
        self.lda_ = LinearDiscriminantAnalysis()
        self.lda_.fit(T, y)
        self._fitted = True
        return self

    def predict_logit(self, X):
        X = self._as_double(X)
        Xd = self.xd_.transform(X)
        C = _oas_covariances_vectorized(Xd)
        T = tangent_euclid(C, self.ref_)
        return self.lda_.decision_function(T).astype(np.float64)


def main():
    root = Path("mne_data/MNE-P3-data")
    exps = sorted([d for d in root.iterdir() if d.is_dir() and d.name.startswith("Experiment")])[:30]
    xs, ys, ds, ss = [], [], [], []
    true = {}
    for exp in exps:
        g = read_gtn_experiment(exp)
        r = preprocess(g.raw, g.events, standard=("Fz", "Cz", "Pz"), sfreq=256.0, l_freq=0.1,
                       tmin=-0.2, tmax=0.8)
        d = g.events[r.event_indices, 2].astype(int)
        y = (d == g.thought_number).astype(int)
        if len(y):
            xs.append(r.data); ys.append(y); ds.append(d); ss.extend([g.subject_id] * len(y)); true[g.subject_id] = g.thought_number
    X = np.concatenate(xs).astype(np.float32); y = np.concatenate(ys); digits = np.concatenate(ds); subs = np.array(ss)
    folds = loso_folds(subs)
    for name, model in [("pyriemann", XdawnRiemann()), ("euclid_ref", XdawnRiemannEuclid())]:
        t = time.time()
        s = evaluate(model, X, y, digits, subs, true, folds)
        print(name, "hit", s.hit_rate_mean, "bacc", s.balanced_acc_mean, "auc", s.auc_mean, "time", time.time() - t, flush=True)


if __name__ == "__main__":
    main()
