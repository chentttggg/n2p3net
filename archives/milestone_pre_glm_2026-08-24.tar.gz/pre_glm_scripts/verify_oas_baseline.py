import sys
import numpy as np

sys.path.insert(0, r"D:\Temp\n2p3-net\src")
from pyriemann.utils.covariance import covariances
from baselines.riemann import _oas_baseline_cov

rng = np.random.default_rng(0)
X = rng.standard_normal((123, 3, 256)).astype(np.float64)
tmp = X.transpose((1, 2, 0))
C1 = np.asarray(covariances(tmp.reshape(3, 123 * 256), estimator="oas"))
C2 = _oas_baseline_cov(X)
print(np.max(np.abs(C1 - C2)), np.allclose(C1, C2))
