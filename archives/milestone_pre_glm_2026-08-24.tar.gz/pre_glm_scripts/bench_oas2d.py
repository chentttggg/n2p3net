import os
import sys
import time

for name in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ.setdefault(name, "24")

sys.path.insert(0, r"D:\Temp\n2p3-net\src")
import numpy as np
from pyriemann.utils.covariance import covariances

rng = np.random.default_rng(0)
X = rng.standard_normal((38000, 3, 256))


def oas_2d(X):
    X = np.asarray(X, dtype=np.float64)
    C, n = X.shape
    Xc = X - X.mean(axis=1, keepdims=True)
    S = (Xc @ Xc.T) / n
    alpha = (S * S).mean()
    mu = np.trace(S) / C
    mu2 = mu * mu
    num = alpha + mu2
    den = (n + 1) * (alpha - mu2 / C)
    rho = 1.0 if den == 0 else min(num / den, 1.0)
    out = (1.0 - rho) * S
    out.flat[:: C + 1] += rho * mu
    return out


tmp = X.transpose((1, 2, 0))
M = tmp.reshape(3, 256 * 38000)
t = time.perf_counter(); C1 = np.asarray(covariances(M, estimator="oas")); t1 = time.perf_counter() - t
t = time.perf_counter(); C2 = oas_2d(M); t2 = time.perf_counter() - t
print("pyriemann", t1, "vec", t2, "speedup", t1 / t2)
print("diff", np.max(np.abs(C1 - C2)), np.allclose(C1, C2))
