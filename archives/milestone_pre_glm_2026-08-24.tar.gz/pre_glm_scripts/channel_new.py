"""模块 #2：坐标式通道身份 + 缺失掩码（data 层，纯 numpy，无 torch）。

职责（blueprint Stage 0 的 0.5「坐标式通道身份」）：
    1. 通道名 → 10-20/10-10 三维坐标（标准坐标，单一事实来源）
    2. 坐标 → 正弦嵌入 E_chn（确定性、无学习、频率封顶，对应 0.5 的「正弦」分支）
    3. 缺失通道掩码 channel_mask

明确「不做」（留给 models 层，避免 data 层引入 torch）：
    - 可学习坐标投影到隐藏维 D（0.5 的「学习」分支）
    - 可学习 mask 嵌入（缺失通道的可学习 token 替换）

三思决策记录（供后续会话追溯）：
    D-coords-source    坐标取 MNE standard_1020 的 8 导值并**硬编码**为单一事实来源：
                       ① 我们的蒙太奇是固定的 8 导（Fz/Cz/P3/Pz/P4/PO7/PO8/Oz），无需泛化到任意通道；
                       ② 确定性、可复现、离线可用、不随 MNE 版本漂移（PO7/PO8 在 standard_1020 中即存在）。
    D-sin-vs-learn     0.5 的「正弦/学习嵌入」是消融轴。正弦分支是确定性无学习，归 data 层；
                       学习分支（MLP 投影 + 可学习 mask token）归 models 层。此处只实现正弦分支。
    D-freq-cap         频率封顶（P0②，review 实测确认）：2^k·π 无封顶时，d_age=61 的 k 高达 29，
                       角度 ~1.3×10⁹ rad 远超 float32 精度（绝对误差 ~162 rad），高维全是数值噪声，
                       相邻年龄/电极的编码近似正交，「平滑调制」归纳偏置丧失。故频率指数封顶
                       k ≤ n_freqs-1（默认 n_freqs=8，最大 2⁷），输出 2*n_freqs 维；高维特征由
                       models 层可学习投影补足，而非无限堆频率。
    D-normalize        坐标以米为单位（MNE 约定），除以头半径 HEAD_RADIUS=0.1m 归一化到「近单位球」。
                       保留径向信息（离头顶距离对 EEG 有意义，故不做逐电极 L2 归一化）。
                       Oz 等枕骨电极 y≈-1.15 略超单位球属正常（真实头非完美球）。
    D-mask-zero        缺失通道的嵌入在 data 层置**零**（而非 NaN），配合 channel_mask 由 models 层
                       用「可学习 mask 嵌入」替换；零值避免 NaN 在神经网络中传播。

契约（输入 → 输出）：
    输入：ch_names（通道名列表，默认标准 8 导）+ channel_mask（可选，(C,) bool，True=存在）
    输出：ChannelIdentity
        - embedding : (C, 6*n_freqs) float32 正弦坐标嵌入，缺失通道为全 0
        - coords    : (C, 3) float32 归一化坐标
        - mask      : (C,) bool，True=通道存在
        - names     : 规范化后的通道名元组

依赖的决策：blueprint 0.5/1.4（坐标嵌入与融合）、P5（格式无关）、preprocess.map_channels（通道规范化）。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Sequence

import numpy as np

from data.preprocess import STANDARD_CHANNELS, canonical_channel_name

# 头半径（m，MNE 标准头模型的近似），用于把米坐标归一化到「近单位球」。
HEAD_RADIUS: float = 0.1

# 正弦编码的频段数（频率指数 k = 0..n_freqs-1，最大 2^{n_freqs-1}）。见 D-freq-cap。
DEFAULT_N_FREQS: int = 8

# 标准 8 导三维坐标（米，来自 MNE standard_1020 montage，单一事实来源，见 D-coords-source）。
# 轴约定：x 左右（-左/+右）、y 前后（+前/-后）、z 上下（+上）。
_STANDARD_COORDS_M: dict[str, tuple[float, float, float]] = {
    "FZ": (0.000312, 0.058512, 0.066462),
    "CZ": (0.000401, -0.009167, 0.100244),
    "P3": (-0.053007, -0.078788, 0.055940),
    "PZ": (0.000325, -0.081115, 0.082615),
    "P4": (0.055667, -0.078560, 0.056561),
    "PO7": (-0.054840, -0.097528, 0.002792),
    "PO8": (0.055667, -0.097625, 0.002730),
    "OZ": (0.000108, -0.114892, 0.014657),
}


@dataclass
class ChannelIdentity:
    """坐标式通道身份。

    Attributes
    ----------
    embedding : np.ndarray
        (C, 6*n_freqs) float32 正弦坐标嵌入；缺失通道为全 0（配合 mask 由 models 层替换）。
    coords : np.ndarray
        (C, 3) float32 归一化坐标（近单位球）。
    mask : np.ndarray
        (C,) bool，True=该通道存在。
    names : tuple[str, ...]
        规范化后的通道名。
    """

    embedding: np.ndarray
    coords: np.ndarray
    mask: np.ndarray
    names: tuple[str, ...]

    @property
    def n_channels(self) -> int:
        return int(self.embedding.shape[0])

    @property
    def dim(self) -> int:
        return int(self.embedding.shape[1])


def standard_coords() -> np.ndarray:
    """返回标准 8 导的归一化坐标 (8, 3)，顺序与 STANDARD_CHANNELS 一致。"""
    m = np.array([_STANDARD_COORDS_M[canonical_channel_name(c)] for c in STANDARD_CHANNELS], dtype=float)
    return m / HEAD_RADIUS


def channel_coords(
    ch_names: Sequence[str],
    *,
    allow_missing: bool = False,
) -> tuple[np.ndarray, np.ndarray]:
    """通道名 → 归一化坐标 (C,3) + 存在掩码 (C,)。

    Parameters
    ----------
    ch_names : Sequence[str]
        通道名列表（大小写不敏感、可带参考后缀，如 'pz'、'Pz-A2'）。
    allow_missing : bool
        False 时遇到未知通道抛 ValueError；True 时未知通道记为缺失（坐标置 0、mask=False）。

    Returns
    -------
    coords : np.ndarray
        (C, 3) 归一化坐标；缺失通道为 0。
    mask : np.ndarray
        (C,) bool，True=该通道存在于标准蒙太奇。
    """
    coords = np.zeros((len(ch_names), 3), dtype=float)
    mask = np.zeros(len(ch_names), dtype=bool)
    for i, name in enumerate(ch_names):
        key = canonical_channel_name(name)
        if key in _STANDARD_COORDS_M:
            coords[i] = _STANDARD_COORDS_M[key]
            mask[i] = True
        elif not allow_missing:
            raise ValueError(f"未知通道 {name!r}，不在标准 8 导蒙太奇 {STANDARD_CHANNELS} 中。")
    return coords / HEAD_RADIUS, mask


def sinusoidal_encode_1d(c: np.ndarray, n_freqs: int = DEFAULT_N_FREQS) -> np.ndarray:
    """单维坐标/标量 → 2*n_freqs 维正弦编码（sin/cos 交替，频率 2^k·π，NeRF 位置编码风格）。

    频率指数 k 封顶于 n_freqs-1（见 D-freq-cap），避免高频段在 float32 下退化为数值噪声。
    通用工具：channel 模块编码 3D 坐标的每一维，metadata 模块复用其编码年龄。

    c : (C,) 归一化值；返回 (C, 2*n_freqs) float32。
    """
    k = np.arange(n_freqs, dtype=float)
    ang = np.pi * c[:, None] * (2.0 ** k)[None, :]  # (C, n_freqs)
    enc = np.concatenate([np.sin(ang), np.cos(ang)], axis=1)  # (C, 2*n_freqs)
    return enc.astype(np.float32)


def sinusoidal_embedding(coords: np.ndarray, n_freqs: int = DEFAULT_N_FREQS) -> np.ndarray:
    """(C,3) 归一化坐标 → (C, 6*n_freqs) 正弦嵌入（确定性、无学习、频率封顶）。

    三个坐标维度各编码 2*n_freqs 维后拼接。models 层用可学习投影将其映射到隐藏维 D。

    Parameters
    ----------
    coords : np.ndarray
        (C, 3) 归一化坐标。
    n_freqs : int
        每维频段数（默认 8）。

    Returns
    -------
    np.ndarray
        (C, 6*n_freqs) float32 正弦嵌入。
    """
    coords = np.asarray(coords, dtype=float)
    if coords.ndim != 2 or coords.shape[1] != 3:
        raise ValueError(f"coords 须为 (C,3)，得到 {coords.shape}。")

    parts = [sinusoidal_encode_1d(coords[:, i], n_freqs) for i in range(3)]
    return np.concatenate(parts, axis=1)  # (C, 6*n_freqs)


def build_channel_identity(
    ch_names: Optional[Sequence[str]] = None,
    channel_mask: Optional[Sequence[bool] | np.ndarray] = None,
    *,
    n_freqs: int = DEFAULT_N_FREQS,
) -> ChannelIdentity:
    """构建坐标式通道身份（坐标 → 正弦嵌入 + 缺失掩码）。

    Parameters
    ----------
    ch_names : Sequence[str] | None
        通道名列表；None 表示使用标准 8 导蒙太奇。
    channel_mask : Sequence[bool] | np.ndarray | None
        显式的缺失掩码（True=存在）；与坐标可查性取「与」。None 表示仅由坐标可查性决定。
    n_freqs : int
        每维频段数（默认 8，见 D-freq-cap）。

    Returns
    -------
    ChannelIdentity
        嵌入 (C, 6*n_freqs)（缺失通道为 0）、归一化坐标、掩码、规范化通道名。
    """
    if ch_names is None:
        ch_names = list(STANDARD_CHANNELS)

    coords, coord_mask = channel_coords(ch_names, allow_missing=True)
    if channel_mask is not None:
        mask = coord_mask & np.asarray(channel_mask, dtype=bool)
    else:
        mask = coord_mask

    emb = sinusoidal_embedding(coords, n_freqs)
    emb[~mask] = 0.0  # 缺失通道置 0（D-mask-zero）

    return ChannelIdentity(
        embedding=emb,
        coords=coords.astype(np.float32),
        mask=mask,
        names=tuple(canonical_channel_name(c) for c in ch_names),
    )
