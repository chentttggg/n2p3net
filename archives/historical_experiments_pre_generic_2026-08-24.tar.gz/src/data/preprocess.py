"""模块 #1：EEG 预处理（网络外格式对齐）。

职责（blueprint Stage 0 的「网络外允许项」，见 constitution P2）：
    1. 重采样到统一采样率（默认 256 Hz）
    2. 0.1 Hz 连续域高通去漂移（constitution E1）
    3. 按 events 切分 epoch（默认 -200~+800 ms）
    4. 幅值阈值伪迹剔除
    5. 通道名规范化 + 重排到标准 8 导蒙太奇 + 缺失通道掩码

明确「不做」（留给模型 Stage 0 或后续模块，避免两处重复实现导致口径漂移）：
    - 基线校正          → 模型内可微基线校正（Stage 0）
    - 参考无关化 / CAR   → 模型内加权再参考（models/reference.py，模块 #5）
    - 幅值 z-score 标准化 → 模型内归一化（Stage 0）
    - 缺失通道插值       → 缺失通道填 NaN + 通道掩码，由模型坐标适配层处理（data/channel.py，模块 #2）

三思决策记录（供后续会话追溯，无需回忆此前的讨论）：
    D-resample-events   MNE 的 ``raw.resample()`` **不会**缩放外部 ``events`` 的 sample 索引。
                        若重采样后不手动缩放，events 会指向错误时间点，epoch 锁时整体错位（隐蔽 bug）。
                        故 ``resample()`` 内部强制同步缩放 events 的第一列。
    D-highpass-iir      0.1 Hz 高通若用 FIR（firwin）需 filter_length ≈ 3.3/0.025 ≈ 132 s，超过
                        短记录的可用数据长度，会报错。默认改用 IIR Butterworth（4 阶）+ filtfilt
                        零相位——核短、对 ERP 潜伏期无相位失真（EEGLAB/ERPLAB 同法）。0.5 Hz 保留为
                        消融对照入口（constitution E1 的 Tanner 2015 结论）。
    D-n-times-align     MNE Epochs 生成 n_times = (tmax-tmin)*sfreq + 1；默认 tmin=-0.2/tmax=0.8
                        @256Hz 会得到 257 点，而模型输入约定为 256（blueprint §0）。故默认
                        ``n_times=256``，epoch 后按 tmin 起点裁剪对齐，消除这一点的形状漂移。
    D-copy-semantics    子函数默认 ``copy=False``（原地，符合 MNE 惯例、省内存）；主入口
                        ``preprocess(..., copy=True)`` 默认先拷贝再原地处理，保证默认不污染调用方。

契约（输入 → 输出）：
    输入：mne.io.Raw（连续数据，任意通道/采样率） + events（(n,3) MNE 格式：sample, prev_id, id）
    输出：PreprocessResult
        - data         : (N, 8, T) float32，缺失通道为 NaN
        - channel_mask : (8,) bool，True=该通道在原始数据中存在
        - sfreq        : 输出采样率
        - tmin         : epoch 起始时间（秒，相对刺激）
        - dropped      : 被伪迹剔除的 epoch 索引（相对「切出的」epoch，非原始 events）

依赖的决策：P2（网络外仅重采样+高通）、E1（0.1Hz 去漂移）、blueprint §0（256 点输入约定）。
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional, Sequence

import numpy as np

import mne

# 标准 8 导蒙太奇（10-20 命名，顺序即模型通道顺序）
STANDARD_CHANNELS: tuple[str, ...] = ("Fz", "Cz", "P3", "Pz", "P4", "PO7", "PO8", "Oz")

# 默认幅值伪迹阈值（V）。干电极噪声偏大（constitution E1），放宽到 ±150 μV。
DEFAULT_REJECT_THRESHOLD: float = 150e-6


@dataclass
class PreprocessResult:
    """单文件预处理结果。

    Attributes
    ----------
    data : np.ndarray
        (N, 8, T) float32 epoch 数据；缺失通道位置为 NaN。
    channel_mask : np.ndarray
        (8,) bool，True 表示该标准通道在原始数据中存在。
    sfreq : float
        输出采样率（Hz）。
    tmin : float
        epoch 起始时间（秒，相对刺激锁时点，通常为负 = 刺激前）。
    dropped : np.ndarray
        被伪迹剔除的 epoch 索引（相对「切出且未裁剪」的 epoch 序列）。
    event_indices : np.ndarray
        (N,) int，最终保留的 epoch 对应的原始 events 行索引（用于对齐逐 event 的标签）。
    """

    data: np.ndarray
    channel_mask: np.ndarray
    sfreq: float
    tmin: float
    dropped: np.ndarray
    event_indices: np.ndarray

    @property
    def n_epochs(self) -> int:
        return int(self.data.shape[0])

    @property
    def n_channels(self) -> int:
        return int(self.data.shape[1])

    @property
    def n_times(self) -> int:
        return int(self.data.shape[2])

    @property
    def n_present(self) -> int:
        """实际存在的通道数。"""
        return int(self.channel_mask.sum())


def _canonical(name: str) -> str:
    """规范化通道名：去空白、转大写、截断参考/索引后缀（如 'Pz-A2' -> 'PZ'）。

    分隔符取连字符/下划线/点/空格的首段。标准 10-20 命名（Fz/Cz/P3/Pz/P4/PO7/PO8/Oz）
    均不含分隔符，故保持原样。
    """
    return re.split(r"[-_.\s]", name.strip().upper(), maxsplit=1)[0]


def canonical_channel_name(name: str) -> str:
    """_canonical 的公开别名：其他 data 模块不得 import 私有函数（audit P2）。"""
    return _canonical(name)


def map_channels(
    raw: mne.io.BaseRaw,
    standard: Sequence[str] = STANDARD_CHANNELS,
    *,
    copy: bool = True,
) -> tuple[mne.io.BaseRaw, np.ndarray]:
    """通道名规范化并重排到标准蒙太奇，缺失通道用掩码标记。

    只保留并重排「存在」的标准通道；缺失通道不在此处插值（填 NaN 由 :func:`preprocess` 完成）。

    Parameters
    ----------
    raw : mne.io.BaseRaw
        原始 Raw。
    standard : Sequence[str]
        目标标准蒙太奇（顺序即输出通道顺序）。
    copy : bool
        True 时返回拷贝、不修改入参；False 时原地修改。

    Returns
    -------
    raw : mne.io.BaseRaw
        仅含「存在的标准通道」、且已按 standard 顺序重排的 Raw。
    mask : np.ndarray
        (len(standard),) bool，True=该标准通道存在。
    """
    if copy:
        raw = raw.copy()

    present: dict[str, str] = {}
    for ch in raw.ch_names:
        key = _canonical(ch)
        if key in present:
            raise ValueError(
                f"通道重名：{present[key]!r} 与 {ch!r} 规范化后均为 {key!r}，无法唯一映射。"
            )
        present[key] = ch
    mask = np.zeros(len(standard), dtype=bool)
    pick_orig: list[str] = []
    for i, std in enumerate(standard):
        orig = present.get(_canonical(std))
        if orig is not None:
            mask[i] = True
            pick_orig.append(orig)

    if not pick_orig:
        raise ValueError(
            f"未找到任何标准通道。标准蒙太奇={tuple(standard)}，"
            f"现有通道={raw.ch_names}。请检查通道命名。"
        )

    # 优先用新版 pick()：等价且无 legacy warning；pick 按 pick_orig 的顺序重排。
    raw.pick(pick_orig)
    return raw, mask


def resample(
    raw: mne.io.BaseRaw,
    events: Optional[np.ndarray] = None,
    sfreq: float = 256.0,
    *,
    copy: bool = False,
) -> tuple[mne.io.BaseRaw, Optional[np.ndarray]]:
    """重采样 raw 并同步缩放 events 的 sample 索引（D-resample-events）。

    Parameters
    ----------
    raw : mne.io.BaseRaw
        待重采样的 Raw。
    events : np.ndarray | None
        (n,3) MNE events。若给定，其第一列（sample 索引）会按新旧采样率比例缩放。
    sfreq : float
        目标采样率。
    copy : bool
        是否先拷贝 raw（避免原地修改）。

    Returns
    -------
    raw : mne.io.BaseRaw
        重采样后的 Raw（采样率 = sfreq）。
    events : np.ndarray | None
        缩放后的 events（与入参无关的新数组）；入参为 None 则返回 None。
    """
    if copy:
        raw = raw.copy()

    old_sfreq = float(raw.info["sfreq"])
    if np.isclose(old_sfreq, sfreq):
        return raw, events

    raw.resample(sfreq)

    if events is not None:
        events = events.copy()
        # MNE 不缩放 events sample 索引，必须手动缩放，否则 epoch 锁时错位（D-resample-events）
        events[:, 0] = np.round(events[:, 0] * sfreq / old_sfreq).astype(int)

    return raw, events


def highpass(
    raw: mne.io.BaseRaw,
    l_freq: float = 0.1,
    *,
    method: str = "iir",
    copy: bool = False,
    verbose: bool = False,
) -> mne.io.BaseRaw:
    """连续域高通去漂移（必须在 epoching 之前、连续数据上做；D-highpass-iir）。

    Parameters
    ----------
    raw : mne.io.BaseRaw
        连续数据。
    l_freq : float
        高通截止频率（Hz）。默认 0.1；0.5 作为消融对照（constitution E1）。
    method : str
        'iir'（默认，Butterworth 零相位，核短）或 'fir'（需长记录，见 D-highpass-iir）。
    copy : bool
        是否先拷贝 raw。
    verbose : bool
        是否打印 MNE 日志。
    """
    if copy:
        raw = raw.copy()
    raw.filter(
        l_freq=l_freq,
        h_freq=None,
        method=method,
        iir_params=dict(order=4, ftype="butter"),
        verbose=verbose,
    )
    return raw


def reject_epochs(
    data: np.ndarray,
    threshold: float = DEFAULT_REJECT_THRESHOLD,
) -> tuple[np.ndarray, np.ndarray]:
    """幅值阈值伪迹剔除（缺失通道的 NaN 不参与判定）。

    Parameters
    ----------
    data : np.ndarray
        (N, C, T) epoch 数据，可能含 NaN（缺失通道）。
    threshold : float
        幅值阈值（V）。任一通道任一时间点 |x| > threshold 即剔除该 epoch。

    Returns
    -------
    clean : np.ndarray
        保留的 epoch。
    dropped : np.ndarray
        被剔除 epoch 的索引（相对输入 data 的第 0 轴）。
    """
    if data.size == 0:
        return data, np.array([], dtype=int)
    # np.nanmax 忽略 NaN；某 epoch 全 NaN 时峰值为 NaN，NaN>threshold 为 False（不剔除）
    peak = np.nanmax(np.abs(data), axis=(1, 2))
    dropped = np.where(peak > threshold)[0]
    keep = np.ones(data.shape[0], dtype=bool)
    keep[dropped] = False
    return data[keep], dropped


def preprocess(
    raw: mne.io.BaseRaw,
    events: np.ndarray,
    *,
    sfreq: float = 256.0,
    l_freq: Optional[float] = 0.1,
    tmin: float = -0.2,
    tmax: float = 0.8,
    n_times: Optional[int] = 256,
    reject_threshold: Optional[float] = DEFAULT_REJECT_THRESHOLD,
    baseline: Optional[tuple[float, float]] = None,
    standard: Sequence[str] = STANDARD_CHANNELS,
    event_id: Optional[dict | Sequence[int]] = None,
    copy: bool = True,
    verbose: bool = False,
) -> PreprocessResult:
    """预处理主入口：通道映射 → 重采样 → 高通 → epoch → 伪迹剔除 → 补齐标准蒙太奇。

    Parameters
    ----------
    raw : mne.io.BaseRaw
        连续 EEG 数据（任意采样率/通道命名）。
    events : np.ndarray
        (n,3) MNE events：[:,0]=sample, [:,1]=prev_id, [:,2]=event_id。
    sfreq : float
        目标采样率（默认 256 Hz）。
    l_freq : float | None
        高通截止频率（默认 0.1 Hz）；None 跳过高通（用于测试或对照预处理）。
    tmin, tmax : float
        epoch 时间窗（秒，相对刺激）。默认 -0.2~+0.8。
    n_times : int | None
        输出时间点数。MNE 自然生成 (tmax-tmin)*sfreq+1 点，默认按 256 裁剪对齐（D-n-times-align）；
        传 None 则保留 MNE 的自然点数。
    reject_threshold : float | None
        幅值伪迹阈值（V）；None 跳过伪迹剔除。
    baseline : tuple[float, float] | None
        若给定，交给 MNE 做基线校正（默认 None——基线校正属于模型 Stage 0，此处仅作对照入口）。
    standard : Sequence[str]
        标准蒙太奇（默认 8 导）。
    event_id : dict | Sequence[int] | None
        要切分的 event 类型；None 表示切 events 中出现的全部类型。
    copy : bool
        默认 True：先拷贝 raw，不污染调用方。
    verbose : bool
        是否打印 MNE 日志。

    Returns
    -------
    PreprocessResult
        见类文档。data 形状 (N, 8, T)，缺失通道为 NaN，channel_mask 标记存在性。
    """
    if events.ndim != 2 or events.shape[1] != 3:
        raise ValueError(f"events 须为 (n,3) 的 MNE 格式，得到 {events.shape}。")

    if copy:
        raw = raw.copy()

    # 1. 通道映射（先 pick，减小后续处理的数据量）
    raw, mask = map_channels(raw, standard=standard, copy=False)

    # 2. 重采样（含 events sample 缩放）
    raw, events = resample(raw, events, sfreq=sfreq, copy=False)

    # 3. 连续域高通去漂移（l_freq=None 表示跳过）
    if l_freq is not None:
        raw = highpass(raw, l_freq=l_freq, copy=False, verbose=verbose)

    # 4. epoch 切分
    if event_id is None:
        event_id = [int(i) for i in np.unique(events[:, 2])]
    epochs = mne.Epochs(
        raw,
        events,
        event_id=event_id,
        tmin=tmin,
        tmax=tmax,
        baseline=baseline,
        preload=True,
        on_missing="warn",
        verbose=verbose,
    )
    data = epochs.get_data()  # (N, C_present, T_mne) float64
    selection = epochs.selection.copy()  # (m,) int，保留 epoch 对应的原始 events 行索引

    # 5. 时间点数对齐（D-n-times-align）
    if n_times is not None and data.shape[2] > n_times:
        data = data[:, :, :n_times]

    # 6. 伪迹剔除（在 present 通道上做，避免 NaN 干扰）
    dropped = np.array([], dtype=int)
    event_indices = selection
    if reject_threshold is not None:
        data, dropped = reject_epochs(data, threshold=reject_threshold)
        keep = np.ones(len(selection), dtype=bool)
        keep[dropped] = False
        event_indices = selection[keep]

    # 7. 补齐到标准蒙太奇（缺失通道填 NaN）
    n_std = len(standard)
    if mask.all():
        out = data.astype(np.float32)
    else:
        out = np.full((data.shape[0], n_std, data.shape[2]), np.nan, dtype=np.float32)
        out[:, mask, :] = data

    return PreprocessResult(
        data=out,
        channel_mask=mask.astype(bool),
        sfreq=float(raw.info["sfreq"]),
        tmin=float(tmin),
        dropped=dropped,
        event_indices=event_indices,
    )
