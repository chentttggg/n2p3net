"""模块 #4：统一加载器（三类异构数据 → (N,8,T) + 标签 + 嵌入 + 元数据）。

职责（blueprint §0 数据面 + techstack 数据源）：
    把三类异构数据（GTN 3 导儿童 / ERP CORE 30 导成人 / 自有 8 导干电极）统一加载为
    SubjectData：预处理后的 epoch + 逐 epoch 标签 + 通道坐标嵌入 + subject 元数据嵌入。

组成（编排 data 层前三个模块）：
    preprocess（格式对齐）→ channel（坐标嵌入）→ metadata（subject 嵌入）。

明确「不做」：
    - 训练循环 / batching / 采样（train 层）
    - 模型输入张量的组装（models 层）
    - 自监督掩码与跨域对齐（train 层，蓝图 §6）

三思决策记录（供后续会话追溯）：
    D-reader-dispatch 文件 → Raw 按扩展名分派到 MNE 的 read_raw_*，不重造轮子；
                     支持 .edf/.bdf/.vhdr/.fif/.set/.cnt/.gdf 等常见 EEG 格式。
    D-label-align     逐 event 标签通过 preprocess 返回的 event_indices 对齐到最终 epoch
                     （MNE 边界丢弃 + 伪迹剔除都会减少 epoch，若不对齐标签会整体错位——关键 bug）。
    D-events-source   events 优先用显式数组；缺省则从 raw.annotations 读取（mne.events_from_annotations）。
    D-lazy-load       read_raw 默认 preload=False（惰性加载，省内存）；preprocess 的 resample/filter
                     会在需要时触发加载。

契约（输入 → 输出）：
    输入：records（list[dict]，每个描述一个文件/被试：path、events、labels、age、sex、subject_id）
    输出：list[SubjectData]
        - data         : (N, 8, T) float32
        - labels       : (N,) int 或 None（与 data 行对齐）
        - channel_mask : (8,) bool
        - E_chn        : (8, D) float32 通道坐标嵌入
        - E_sub        : (D,) float32 subject 嵌入
        - age / sex / subject_id / sfreq

依赖的决策：preprocess.event_indices（标签对齐）、channel.build_channel_identity、metadata.build_subject_embedding。
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Sequence

import numpy as np

import mne

from data.channel import DEFAULT_N_FREQS, build_channel_identity
from data.metadata import build_subject_embedding, normalize_sex
from data.preprocess import STANDARD_CHANNELS, preprocess

# 扩展名 → MNE reader（D-reader-dispatch）
_EXTENSION_READERS = {
    ".edf": mne.io.read_raw_edf,
    ".bdf": mne.io.read_raw_bdf,
    ".vhdr": mne.io.read_raw_brainvision,
    ".fif": mne.io.read_raw_fif,
    ".set": mne.io.read_raw_eeglab,
    ".cnt": mne.io.read_raw_cnt,
    ".gdf": mne.io.read_raw_gdf,
}


@dataclass
class SubjectData:
    """单个被试（或单个记录）的统一样本。

    Attributes
    ----------
    data : np.ndarray
        (N, 8, T) float32 epoch 数据；缺失通道填 0（NaN 已在 build_subject 转 0，避免毒化模型）。
    labels : np.ndarray | None
        (N,) int 逐 epoch 标签，与 data 行对齐；None 表示无标签（如自监督预训练数据）。
    channel_mask : np.ndarray
        (8,) bool。
    E_chn : np.ndarray
        (8, D) float32 通道坐标嵌入。
    E_sub : np.ndarray
        (D,) float32 subject 元数据嵌入。
    age : float | None
    sex : str
        'M' / 'F' / 'unknown'。
    sfreq : float
        采样率（Hz）。
    tmin : float
        epoch 起点时间（秒，相对刺激；由 PreprocessResult 透传，audit P1-1）。
    subject_id : str
        被试/记录标识。
    """

    data: np.ndarray
    labels: Optional[np.ndarray]
    channel_mask: np.ndarray
    E_chn: np.ndarray
    E_sub: np.ndarray
    age: Optional[float]
    sex: str
    sfreq: float
    tmin: float
    subject_id: str

    @property
    def n_epochs(self) -> int:
        return int(self.data.shape[0])

    @property
    def n_times(self) -> int:
        return int(self.data.shape[2])


def read_raw(path: str | Path, *, preload: bool = False, **kwargs) -> mne.io.BaseRaw:
    """按扩展名分派到 MNE reader，读取文件为 Raw（D-reader-dispatch）。

    Parameters
    ----------
    path : str | Path
        数据文件路径。
    preload : bool
        是否立即加载进内存（默认 False 惰性加载）。
    **kwargs
        透传给 MNE reader。
    """
    path = Path(path)
    reader = _EXTENSION_READERS.get(path.suffix.lower())
    if reader is None:
        raise ValueError(
            f"不支持的文件格式 {path.suffix!r}，支持：{sorted(_EXTENSION_READERS)}。"
        )
    return reader(str(path), preload=preload, verbose=False, **kwargs)


def events_from_annotations(
    raw: mne.io.BaseRaw,
    *,
    event_id: Optional[dict] = None,
) -> np.ndarray:
    """从 raw.annotations 构造 MNE events 数组 (n,3)（D-events-source 的缺省分支）。"""
    events, _ = mne.events_from_annotations(raw, event_id=event_id, verbose=False)
    return events


def build_subject(
    raw: mne.io.BaseRaw,
    events: np.ndarray,
    labels: Optional[Sequence[int]] = None,
    *,
    age: Optional[float] = None,
    sex: Optional[str | int] = None,
    subject_id: str = "",
    n_freqs: int = DEFAULT_N_FREQS,
    **preprocess_kwargs,
) -> SubjectData:
    """组装单个被试：preprocess + 标签对齐 + 通道嵌入 + subject 嵌入。

    Parameters
    ----------
    raw : mne.io.BaseRaw
        连续数据。
    events : np.ndarray
        (n,3) MNE events。
    labels : Sequence[int] | None
        逐 event 标签（长度 = events 行数）；None 表示无标签。
    age : float | None
    sex : str | int | None
    subject_id : str
    n_freqs : int
        每维频段数（正弦编码封顶，见 channel.D-freq-cap）。
    **preprocess_kwargs
        透传给 preprocess（sfreq/l_freq/tmin/tmax/reject_threshold 等）。

    Returns
    -------
    SubjectData
        见类文档。
    """
    result = preprocess(raw, events, **preprocess_kwargs)

    # 缺失通道 NaN → 0（D-nan-to-zero）：preprocess 用 NaN 标记缺失通道，但模型 forward 无 NaN
    # 处理会毒化 logit（review v3 P0 断链）；此处转 0，channel_mask 保留供 model 层再参考重归一化用。
    data = np.nan_to_num(result.data, nan=0.0, posinf=0.0, neginf=0.0)

    # 标签对齐（D-label-align）：用 event_indices 把逐 event 标签对齐到最终 epoch
    aligned_labels: Optional[np.ndarray] = None
    if labels is not None:
        labels_arr = np.asarray(labels)
        if labels_arr.shape[0] != events.shape[0]:
            raise ValueError(
                f"labels 长度须等于 events 行数，得到 {labels_arr.shape[0]} vs {events.shape[0]}。"
            )
        aligned_labels = labels_arr[result.event_indices].astype(np.int64)

    # 通道坐标嵌入（默认 8 导；preprocess 的 standard 改变时按同名通道构建，review v6 P1）
    standard = preprocess_kwargs.get("standard", STANDARD_CHANNELS)
    identity = build_channel_identity(
        ch_names=list(standard), channel_mask=result.channel_mask, n_freqs=n_freqs
    )

    # subject 元数据嵌入
    subj = build_subject_embedding(age, sex, n_freqs=n_freqs)

    return SubjectData(
        data=data,
        labels=aligned_labels,
        channel_mask=result.channel_mask,
        E_chn=identity.embedding,
        E_sub=subj.embedding,
        age=age,
        sex=normalize_sex(sex),
        sfreq=result.sfreq,
        tmin=result.tmin,
        subject_id=subject_id,
    )


def load_dataset(
    records: Sequence[dict],
    *,
    n_freqs: int = DEFAULT_N_FREQS,
    preprocess_kwargs: Optional[dict] = None,
) -> list[SubjectData]:
    """批量加载多个记录 → list[SubjectData]。

    record 结构（dict）：
        path        : str，数据文件路径（必需）
        events      : np.ndarray | None，(n,3) MNE events；None 表示从 annotation 读
        event_id    : dict | None，annotation 的事件 id 映射（events 为 None 时用）
        labels      : Sequence[int] | None，逐 event 标签
        age         : float | None
        sex         : str | int | None
        subject_id  : str
    """
    preprocess_kwargs = preprocess_kwargs or {}
    out: list[SubjectData] = []
    for rec in records:
        raw = read_raw(rec["path"])
        events = rec.get("events")
        if events is None:
            events = events_from_annotations(raw, event_id=rec.get("event_id"))
        out.append(
            build_subject(
                raw,
                events,
                labels=rec.get("labels"),
                age=rec.get("age"),
                sex=rec.get("sex"),
                subject_id=rec.get("subject_id", ""),
                n_freqs=n_freqs,
                **preprocess_kwargs,
            )
        )
    return out
