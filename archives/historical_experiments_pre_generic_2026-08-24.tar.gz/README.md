# Historical experiment archive

Created: 2026-08-24

This archive contains artifacts removed when N2P3-Net adopted the generic EEG
ingress and `neural_ride_v8` recipe as the only active interface.

Included:

- historical run records and baseline result JSON files;
- one-off diagnostics and sweep scripts;
- snapshots of dataset-specific entry points and the pre-generic data modules;
- the historical lessons document and superseded dataset/recipe specifications.

Not included:

- raw `mne_data` downloads;
- any dataset/tensor cache, pretrained checkpoint, or interpreter/tool cache;
- the active Neural-RIDE model, tests, evaluation protocol, or source papers.

`MANIFEST.sha256` records SHA-256 and byte size for every archived file. Paths
are relative to this archive root. Restore an item only for explicit historical
reproduction; do not copy an old entry point back into the active tree.
