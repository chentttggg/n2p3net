# Neural-RIDE 配方与入口规范

> 版本：v1（2026-08-24）  
> 适用：GTN、BNCI2014-008、Brain Invaders 2014a、ERP CORE 的 Neural-RIDE 训练入口。  
> 优先级：constitution / transfer_policy > blueprint > 本规范 > CLI 文档。

## 1. 强制分层

训练系统必须拆为三个互不代写的契约：

1. `DatasetSpec`：只声明通道、采样率、滤波、物理时间轴、基线能力和验证被试比例；
2. `TaskCapabilities`：只声明是否有单试次标签、GTN 九数字集合标签及类别先验；
3. `NeuralRideRecipe`：唯一声明模型默认值、Loss、PCW/residual 阶段日程、早停和审计。

实验入口只允许选择 `DatasetSpec`、传入数据和登记显式消融。禁止在入口内复制一份
`trainer_kwargs` 或依靠 `TrainerConfig` 的通用默认值形成隐式训练配方。

代码单一事实来源：[`src/train/recipe.py`](../src/train/recipe.py)。正式 recipe 名称为
`neural_ride_v8`，每次运行必须把 recipe、task、model kwargs 和 trainer config 写入 record。

## 2. 标准训练语义

所有 Neural-RIDE 数据集默认共享：

- `lambda_pcw=0.3`、`lambda_recon=0.05`、`lambda2=0.3`、`lambda3=0.01`；
- `5 epoch PCW-only -> 10 epoch residual ramp -> joint`；
- residual branch dropout 为 0；
- joint 阶段才启动 checkpoint selection 与 patience=6；
- TCN depth=3、BN、bandpass tokenizer、无 tokenizer 后置 BN/激活；
- 重建 profile 只由当前 outer-fold 的 inner-train 试次估计。

能力门只改变数据中物理不存在的监督：

| Task | `lambda_digit` | `pos_weight` | 其他 v8 核心 Loss/阶段 |
|---|---:|---:|---|
| GTN 9 选 1 | 0.2，K={3,5,10,15} | 8 | 保持 |
| 普通 binary oddball | 0（无 thought-number set） | 5 | 保持 |

二分类入口若请求 `lambda_digit>0` 必须报错；标准 recipe 若静默关闭 PCW 或重建也必须报错。

## 3. 物理预处理 profile

正式辅助数据缓存统一使用 `neural_ride_v8` profile：

- 连续域高通 0.1 Hz，无低通；
- 256 Hz；
- 刺激锁时 `[-200,+1200) ms`，358 点，右边界 exclusive；
- 保留真实 `[-200,0) ms` 基线，模型使用 trial baseline standardization；
- 缓存内必须记录 schema/profile/sfreq/filter/time-axis/n_times，读取时逐项 fail-closed。

文件名：`{dataset}_neural_ride_v8.npz` 与同 stem 的 metadata CSV。历史
`{dataset}.npz` 是 `legacy_moabb`（1–24 Hz、[0,+1000) ms），只用于复现，不允许由标准入口
静默读取。旧缓存不能通过裁剪或补零升级，因为缺失的刺激前基线与 0.1–1 Hz 信息不可恢复。

## 4. 数据集入口

| 入口 | 原生通道 | 任务 |
|---|---:|---|
| `experiments/run_bnci008_loso.py` | 8 | BNCI 独立 binary LOSO |
| `experiments/run_bi2014a_loso.py` | 16 | Brain Invaders 独立 binary LOSO |
| `experiments/run_erpcore_loso.py` | 8 | ERP CORE P3 独立 binary LOSO |
| `experiments/run_n2p3net_gtn.py` | 3（默认） | GTN trial + multi-K digit LOSO |

BNCI/BI 的独立 LOSO 是数据集表征能力实验，可以使用该数据集自身的 target/non-target 标签。
当它们作为 GTN T3 辅助域时，仍严格遵守 `transfer_policy`：辅助试次只进入域条件仿射和
`L_MMD`，不得进入 GTN 的 target/PCW/early/reconstruction/digit Loss。

BI2014a 使用原生 16 导 standard_1020 坐标；Pz 必须按通道名解析为索引 10，禁止沿用“非 3 导
即索引 3”的假设。通道坐标缺失或 active model channel 无法从辅助域映射时必须报错。

## 5. 标准命令

```powershell
# 生成不可与旧缓存混淆的正式物理缓存
.venv\Scripts\python.exe experiments\download_datasets.py --dataset bnci008
.venv\Scripts\python.exe experiments\download_datasets.py --dataset bi2014a

# 独立数据集 LOSO
.venv\Scripts\python.exe experiments\run_bnci008_loso.py --models n2p3net --epochs 30
.venv\Scripts\python.exe experiments\run_bi2014a_loso.py --models n2p3net --epochs 30

# 轴匹配后的 T3；仍由 domain mask 隔离所有主任务 Loss
.venv\Scripts\python.exe experiments\run_n2p3net_gtn.py --aux-dataset bnci008
```

## 6. 验收

- BNCI 与 BI adapter 的核心 trainer config 除 capability-gated `lambda_digit` 外必须相同；
- record 必须包含 dataset preprocessing profile、recipe 和完整 resolved config；
- 每个新入口必须通过通道坐标、Pz 定位、物理轴、核心 Loss 和阶段日程测试；
- 入口重命名、增加数据集或增加消融时，不得在脚本内新增第二套默认配方。
