# N2P3-Net 经验与教训

> 本文档是历史评审、失败诊断、Loss 审计和跨数据集实验的集中结论。它保留证据和决策理由，不保留已经被后续结果推翻的旧配置作为可选方案。
>
> 状态：截至 2026-08-24。`当前采用` 表示现行默认或硬约束；`仅消融` 表示可以复现实验但不能作为默认；`已否决` 表示不得回退；`待验证` 表示尚未取得确认性证据。

## 1. 先记住的结论

1. **P300 任务的最终风险不是独立 trial BCE，而是 subject/digit 证据排序。** 训练应保留 trial-level 判别，但验收必须看训练侧校准的 `LLR hit@K`，默认 `K=15`，并报告 coverage/N。
2. **容量不是首要瓶颈。** 2.5k/7.3k 参数的 Mini 与 38.5k 模型在早期诊断中 AUC 接近；真正的收益来自保留 P3b、参考和频带结构，而不是堆深度。
3. **少导数据不能默认做均匀 CAR。** GTN 的 3 导鼻参考数据上，强制均匀再参考会显著削弱 P3b；当前参考层必须恒等初始化、允许不变换，并由数据决定是否轻度再参考。
4. **统计上“位置对了”不等于“网络学会了潜伏期”。** 当前 `tau0/sigma` 与 ERP 峰值一致主要来自 fold-local 校准初始化；PCW 未通过 claim gate 前只能称为结构化 ERP 窗。
5. **可解释性辅助目标必须先证明可识别，再谈生理意义。** 删除绝对尺度后的表示无法恢复单试次绝对微伏幅值，因此 `L_amp` 不能作为默认训练约束。

## 2. 已验证且当前采用

### 2.1 数据事实和评估分母

- GTN 实际为 NIX/HDF5 容器，事件流是 `S 1..9`，没有 `0` 或第 10 个数字；target 基率按 `1/9`，`pos_weight` 约为 8。把 `pos_weight` 从 8 改成 9 的旧结论已否决。
- 当前运行口径是 248 个目录中 242 名可评估被试：缺 thought 元数据、全试次质量剔除和重复 NIX subject id 都要写入显式质量表。评估器不得把 `true_digits` 中没有可用试次的被试静默计入分母。
- `Data/` 里存在多个 `.txt` 时不能取文件系统返回的第一个；应以 NIX 内部 subject id 精确匹配，孤儿文件告警。
- 9 选 1 不报告原始 trial accuracy。必须报告 subject-level hit@K、trial AUC、balanced accuracy，并附 digit-prior 与 count-only 基线。

### 2.2 决策层的校准顺序

旧做法是先累加带常数偏置的 logit，再对 9 个数字的 score 做 z-score。该 z-score 只做整体仿射变换，不能消除 `c * n_digit`，因此当每个数字试次数不等时会改变 argmax。

当前顺序是：

1. 只用训练侧拟合正类权重和 Platt LLR 校准；
2. 在每个 subject 内对有限 trial logit 做中心化；
3. 对每个数字按采集顺序固定取 `K in {1,3,5,10,15,all}`，累加或取均值；
4. 处理空集合和 coverage，再取 9 个数字的 argmax。

score 后 z-score 只能用于展示，不承担校准。测试折中心化后的 balanced accuracy 必须标为 transductive，不能冒充归纳评估。

### 2.3 训练协议和过拟合

- 242 人诊断显示训练损失持续下降而 held-out 指标在约 10-11 epoch 后下降；50 epoch 的全量结果明显差于 10 epoch。当前必须使用 subject-disjoint validation、早停和 best-weight restoration。
- batch size、seed、fold、验证规则和输入标准化必须由协议固定；训练侧统计量不能读取测试被试。
- GTN 有真实刺激前基线，BNCI 等从 0 ms 开始的数据没有同等基线。标准化策略必须按数据集的 baseline 结构配置，不能复用 GTN 的短基线估计。
- 3 导 GTN 的零填充路径与真实 8 导数据不是同一问题。BNCI008 和 ERP CORE 的实测都显示真实空间通道带来增益；缺失通道 mask 必须贯穿增强、Trainer、参考层和模型前向，不能给零填充通道添加噪声或参考抖动。

### 2.4 参考层和时间滤波

- 强制均匀 CAR 在 GTN 3 导上把 Fz/Cz/Pz 的共同 P3b 正波相减，实测 Pz 差值和单试次 SNR 明显下降。这个旧前端已否决。
- 当前门控参考层 `out = X - g * (1 * w^T X)` 使用 `w=softmax`、`g=0` 恒等初始化，并按 domain/mask 取有效通道。它可以学习“保持记录参考”或小幅域内再参考，但不是默认 CAR。
- 0.1 Hz 连续域高通、epoch 前执行、再做基线校正，是当前默认。0.5 Hz 高通只作负面消融，不能作为默认去漂移步骤。
- 随机初始化的长卷积核集中在约 60 Hz，ERP 信息没有被前端主动保留；带通初始化使长核靠近 delta/theta、短核覆盖更高频，GLM v3 全量 GTN 结果从 v2 的 hit `0.8182`/AUC `0.7462` 提升到 `0.8388`/`0.7543`。这是 seed-0 的强方向性证据，不替代多 seed 确认。

## 3. Loss 与可解释性教训

### 3.1 当前可辩护的默认基线

在确认新损失之前，使用 fold-weighted `BCEWithLogits(L_target)` 作为清晰对照；验证侧选择依据应是 Head-A/LLR 端点，不是把没有任务证据的辅助项全部相加后的 total loss。

`L_early` 是与主标签同源的辅助深监督，不是独立生理标签。只有在嵌套 subject-disjoint validation 中稳定改善 `LLR hit@15` 才能恢复。

### 3.2 已否决或默认关闭的项

| 项 | 当前处置 | 原因 |
|---|---|---|
| `L_amp` | **已否决为默认训练项；`lambda_amp=0`** | 表示经过参考/标准化后缺少绝对尺度，且 target 使用随 attention 移动的模型输出；无法证明恢复物理微伏 |
| `L_tau` | **PCW 冻结时关闭；继续学习须过 gate** | 当前惩罚主要是 `Delta tau` 收缩，不提供逐试次真实 latency 标签 |
| `L_jit` | **默认 0，仅消融** | 已知平移等变性未收敛，且与 P300 的刺激锁定时间判别冲突 |
| `L_MMD` | **不进主确认性 Loss** | 无条件边缘对齐可能抹平年龄、参考、target 条件等真实差异；固定核宽也依赖特征尺度 |
| raw waveform MSE | **已否决为 Neural-RIDE 的成分重建目标** | EEG 的 1/f 结构会让绝对误差由低频支配，不能把此现象直接解释成低频信息有害 |
| FAME 五带等权直接移植 | **已否决** | 其机制针对 log-power masked reconstruction，不等价于本项目的 trial BCE 或标量幅值回归 |

如果未来恢复幅值回归，必须同时提供独立绝对尺度、同一 reference/baseline 定义、固定或 detached 的 target、fold-local robust scaling，以及尺度变换等变性测试；否则只能把幅值作为解释性测量。

### 3.3 PCW claim gate

必须同时满足以下四项，才能使用“learned single-trial ERP localization”措辞：

1. synthetic known-shift：相关 `>=0.80` 且 RMSE `<=40 ms`；
2. gradient health：median tau/reference gradient ratio `>=1e-3` 且 `tau0` drift `>=2 ms`；
3. real split-half stability：相关 `>=0.70` 且 median absolute difference `<=30 ms`；
4. PCW 相对 fixed-window 和 mean-pool 对照的锁定分数提升 `>=0.005`。

当前三数据集取证中 `tau0` drift 为 0，target/non-target 的逐试次 tau 差异不稳定，因此 gate 未通过。当前正确表述是“ERP 校准驱动的结构化 ERP 窗和成分读出”。

## 4. 架构决策的演化结果

以下不是要恢复的历史方案，而是用来解释当前设计边界：

- Conformer 不再是默认主干；Stage 2 深度降为消融轴，容量预算不超过 50k。原因是 CNN/LDA 与 Mini 诊断显示容量不是主要瓶颈。
- 自由 attention、多查询集合匹配、Hungarian loss、事后 soft-argmax 潜伏期读取都不采用。参数化窗口用不同先验中心做位置寻址，但这不自动赋予其物理可识别性。
- 旧的“两个独立投票器”被 Neural-RIDE 统一为一个多任务模型：PCW 支路只读 `H_N2/H_P3a/H_P3b`，residual 支路只读 `g_residual`，最终用受 Trainer 控制的加性融合；PCW-only 和 residual-only 只用于审计。
- residual 逐步开放：先关闭 residual，再线性 ramp；不要用自由 gate 重新把 PCW 权重压到零。branch dropout 默认 0，只有出现明确的 PCW 梯度饥饿证据时才做预注册消融。
- GTN 集合级损失按 subject x digit 构造完整 fixed-K evidence set，缺数字或不足 K 的 subject 不进入集合损失并记录 coverage；不得从外层测试被试构造训练集合。

## 5. 跨数据集和辅助数据

- GTN 是 9 选 1 主域；Brain Invaders 是干电极 P300 辅助域；BNCI008 是 8 导空间对照；ERP CORE 是成人 P3 辅助域；自有成人 8 导数据才是部署目标域。
- 辅助数据只能用于预训练初始化、冻结骨干对照或域对齐；主分类头和最终验收由 GTN 决定。
- 60 被试试点中，辅助预训练微调没有达到显著收益，冻结骨干没有优势，N2P3-Net MMD 对齐也没有显著收益。因此默认退回 GTN from-scratch；任何再次启用都必须完整重跑 T0/T1/T2/T3。
- 最新矩阵中，GTN 与 BNCI008 上 N2P3-Net 与 EEGNet 基本打平，bi2014a 16 导干电极上 N2P3-Net 显著超越 EEGNet。结果支持“跨设备/通道的结构先验有价值”，不支持把某个辅助域当成普适增益来源。

## 6. 工程教训

- 运行输出必须按 `run/model/spec` 隔离；曾发生多个模型覆盖同一个 `record.json`，现已改为模型独立子目录。
- 缓存名称必须包含采样率、滤波、时间窗、通道和样本范围；不得让旧的 `n<N>` 子集缓存悄然改变 LOSO 分母。
- `baseline_n` 不能固定为 51，必须由 `sfreq/tmin/T` 推导或显式校验；MOABB 的 `tmin=0` 不能套用 GTN 的刺激前基线。
- P300 采集标记的 LSL 时间戳不能丢弃后用本地轮询时间代替。自有数据在进入潜伏期分析前，需要样本级时钟校正和光电/音频 onset 验证。
- 设备代码统一使用 CUDA -> XPU -> CPU 动态选择、`.to(DEVICE)` 和 bf16 AMP；IPEX 已弃用，不能作为新依赖恢复。

## 7. 仍然开放的问题

- 多 seed、完整队列的 confirmatory run 尚未完成；seed-0 结果只能作开发/复核证据。
- Neural-RIDE 的集合损失、分阶段 residual 开放和成分频谱重建仍须在锁定的 LOSO 协议中验证，不能因为写入 blueprint 就视为已证实。
- PCW 前端在门控参考、BN 和带通初始化全部改变后，仍需重新完成 claim gate。
- REST 与 per-domain gated reference 的跨参考比较、bi2014a 失败被试画像和自有成人数据验证仍属 Phase 3/4 工作。

## 8. 证据等级

- **硬事实**：NIX 结构、事件标签、当前 cohort/缓存统计、公开数据的实际输出。
- **实测决策证据**：固定 seed/fold/runner 的配对实验和数值诊断；必须同时记录样本量与协议。
- **候选机制**：文献支持或小样本方向性结果；只能进入预注册消融，不能写成已证实机制。
- **生理解释**：必须同时有任务指标、ERP 统计和 split-half/跨被试稳定性；单个 attention、tau 或频谱图不构成因果证明。
