# N2P3-Net 数据集与数据角色

> 面向 oddball/P300 检测和 9 选 1 认知判定。本文档只保留数据事实、获取方式、许可和接入边界；辅助数据的训练红线见 [`transfer_policy.md`](transfer_policy.md)。

## 1. 数据角色总表

| 数据集 | 任务/人群/设备 | 通道与格式 | 项目角色 |
|---|---|---|---|
| GTN | Guess the Number，7-17 岁儿童，湿电极 | Fz/Cz/Pz，NIX/HDF5 + thought `.txt` | **主域与 9 选 1 验收锚点** |
| Brain Invaders bi2014a | P300 游戏，成人，干电极 | 16 导，`.mat/.csv`，MOABB 接口 | 干电极单试次二分类辅助域 |
| BNCI2014_008 | P300 speller，ALS 被试 | 8 导、256 Hz，MOABB | 真实 8 导空间对照/辅助域 |
| ERP CORE P3 | visual oddball P3，成人 | 30 导、EEGLAB/BIDS，MOABB | 成人 P3 辅助域/跨年龄对照 |
| 自有 BrainSync 数据 | 成人为主，8 导干电极 | EDF/BDF + marker | 最终部署目标域，不混入 GTN |

## 2. GTN：主域

- 场景：被试心选 1-9 中一个数字，刺激序列中 target 概率约为 `1/9`。
- 原始数据：EEGBase 下载，NIX/HDF5 容器；不能按 BrainVision 或普通 MNE 文件读取。
- 事件：实际 NIX 事件为 `S 1..9`，不存在 `0` 或第 10 个数字。`pos_weight` 约为 8，具体值由训练 fold 的 `nneg/npos` 估计。
- 当前缓存口径：248 个目录中 242 名可评估被试。缺 thought 元数据、全试次质量剔除和重复 NIX subject id 必须写入质量表，不能静默缩小分母。
- 许可：CC BY-NC，学术研究可用；商业化需要重新核验授权。
- 读取边界：`Data/` 中多个 `.txt` 时，以 NIX 内部 subject id 精确匹配，不可取文件系统返回的第一个。
- 处理：连续域 0.1 Hz 高通 -> epoch `[-200,+800] ms` -> 阈值伪迹剔除；重采样到 256 Hz。GTN 的刺激前 baseline 可用于 fold-local 标准化。
- 任务评估：LOSO、subject-level `LLR hit@K`，主指标为 `LLR hit@15`；trial AUC/bacc 是次指标。

## 3. MOABB 数据集

MOABB 统一产生 `X (n_epochs, n_channels, n_times)`、标签和 metadata。推荐用项目脚本下载；被试数量以当前 MOABB 版本和实际缓存为准，并写入 metadata，不从文献人数硬编码。

| `--dataset` | 数据 | 当前接入约定 |
|---|---|---|
| `erpcore` | ERP CORE P3，约 40 成人、30 导、1024 Hz | 选择项目 8 导子集，重采样到 256 Hz，保持 subject/session/run |
| `bnci008` | 8 被试、8 导、256 Hz | 电极集合与项目 8 导配置对齐；无刺激前 baseline，必须用显式替代标准化策略 |
| `bi2014a` | 干电极 P300，16 导、约 64 个 MOABB subject | 保留全 16 导用于干电极场景；不要把 16 导误写成项目 8 导部署配置 |

推荐的项目 8 导顺序为：`Fz, Cz, P3, Pz, P4, PO7, PO8, Oz`。GTN 的 3 导是 `Fz, Cz, Pz`，不是这个序列的简单前三列；接入时必须使用通道名映射和 mask。

示例：

```python
from moabb.datasets import ErpCore2021_P3
from moabb.paradigms import P300

channels = ["Fz", "Cz", "P3", "Pz", "P4", "PO7", "PO8", "Oz"]
paradigm = P300(resample=256, channels=channels)
X, y, metadata = paradigm.get_data(dataset=ErpCore2021_P3(), subjects=[1, 2, 3])
```

MOABB 预切好的 epoch 可以跳过重复的 epoch 切分，但仍需记录重采样、滤波、baseline、参考、通道子集和标准化口径。`tmin=0` 的数据不能套用 GTN 的 51 点刺激前 baseline。

## 4. 下载与许可

- GTN：<https://eegdatabase.kiv.zcu.cz>，需要注册；论文 DOI `10.1038/sdata.2016.121`。
- Brain Invaders：<https://doi.org/10.5281/zenodo.3266223>，引用原始数据论文并核验 Zenodo 许可。
- ERP CORE：<https://erpinfo.org/erp-core>，OSF 入口 <https://osf.io/thsqg/>；使用前核验对应子集的 CC-BY/CC-BY-SA 条款。
- BNCI Horizon 2020：<https://bnci-horizon-2020.eu/database/data-sets>。

MOABB 的 ERP CORE、Brain Invaders、BNCI008 可自动下载；GTN 仍需 EEGBase。缓存不得提交到代码仓库，许可和来源写入实验记录。

## 5. 接入检查清单

1. 读取原始文件并记录格式、采样率、时间起点、reference、事件编码和 subject/session/run。
2. 显式选通道或生成坐标 embedding；不存在的通道使用 mask，不用恒零通道伪装成真实观测。
3. 确认 baseline 是否存在；若不存在，选择并注册数据集专用策略。
4. 计算质量剔除率、每 subject 试次数、target 比例和缺失数字，并写入缓存 metadata。
5. 先跑单试次 AUC/bacc，再按 transfer policy 进入预训练或域对齐；辅助域精度不能替代 GTN 主验收。
