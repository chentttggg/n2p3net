"""Brain Invaders 2014a thin entry point for the standardized P300 LOSO engine."""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from experiments.run_bnci008_loso import main  # noqa: E402


if __name__ == "__main__":
    main(default_dataset="bi2014a", lock_dataset=True)
