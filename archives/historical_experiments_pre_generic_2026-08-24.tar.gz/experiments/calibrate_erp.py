"""自适应 ERP 成分窗校准：新数据集接入的前置步骤（免人工拍超参）。

动机（2026-08-24）：τ0/σ 先验依赖数据集一致性——GTN 实测 P3b 峰值 460-490ms（旧先验
350ms 曾致 3+pt AUC 损失）；BNCI-008 用成人 380ms 拍脑袋先验后与 EEGNet 差 6.6pt。
本工具对完整缓存做描述性校准。其输出不得回灌同一数据集的 LOSO；LOSO runner 默认在
每个外层折的内部训练被试上重新校准。只有独立开发集冻结的先验才能作为固定输入。

方法（梯度/半高宽法，无人工参数）：
    1. 逐被试基线校正 → grand-average 差值曲线 d_c(t) = mean(target) − mean(nontarget)
    2. 成分峰检测（按生理搜索窗 + 显著性检验）：
       P3b：[250, 700]ms 内 d̄(t)（跨通道均值）最大值 → τ_P3b = argmax
       N2 ：[100, 350]ms 内 d̄(t) 最小值，且 |min| ≥ 0.4·|P3b 峰|（显著性守卫）
       P3a：[180, 400]ms 内 N2 与 P3b 之间的局部极大（存在性可选）
    3. σ（窗宽）：峰附近半高全宽 FWHM → σ = FWHM / 2.355（高斯等效），clamp [40, 160]
    4. τ 边界：τ ± max(80, 1.5σ) ms；σ 边界 [max(30, σ/2), min(180, 2σ)]

用法：
    .venv/Scripts/python.exe experiments/calibrate_erp.py --dataset gtn
    .venv/Scripts/python.exe experiments/calibrate_erp.py --dataset bnci008
    # 输出只作描述/独立开发先验制备；同数据集 LOSO 使用 runner 默认 fold 校准

输出：experiments/cache/erp_calib_<dataset>.json（tau0_ms / tau0_bounds / sigma_bounds /
     每成分证据：峰潜伏期、幅值、FWHM、信噪比）。
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))

import numpy as np

from models.erp_calibration import calibrate_erp_fold
from models.time_axis import EpochTimeAxis

# 生理搜索窗（ms）：只限定搜索范围，不预设峰位（峰位由数据决定）
SEARCH = {
    "N2": (100.0, 350.0),
    "P3a": (180.0, 420.0),
    "P3b": (250.0, 700.0),
}
FWHM_FACTOR = 2.355  # 高斯等效：FWHM = 2.355σ


def _load_dataset(name: str, cache_dir: Path):
    """返回 (X (N,C,T) float32, y (N,) bool/int, subject_ids (N,) str, t_ms (T,), ch_names)"""
    if name == "gtn":
        from experiments.run_gtn_baseline import _load_gtn_cache

        X, y, digits, subject_ids, _, _ = _load_gtn_cache(
            cache_dir / "gtn_3ch_sf256_lf0.1_tm-0.2_tx1.2_nall.npz"
        )
        t_ms = -200.0 + np.arange(X.shape[2]) * 1000.0 / 256.0
        return X.astype(np.float32), y.astype(bool), subject_ids.astype(str), t_ms, ("Fz", "Cz", "Pz")
    from data.auxiliary import get_auxiliary_dataset_spec, load_auxiliary

    spec = get_auxiliary_dataset_spec(name, preprocessing_profile="neural_ride_v8")
    aux = load_auxiliary(
        name,
        str(cache_dir),
        preprocessing_profile=spec.preprocessing.name,
    )
    X = aux.X.astype(np.float32)
    y = aux.y.astype(bool)
    t_ms = aux.preprocessing.tmin_ms + (
        np.arange(X.shape[2]) * 1000.0 / aux.preprocessing.sfreq
    )
    names = aux.channel_names
    return X, y, aux.subject_ids.astype(str), t_ms, tuple(names)


def _baseline_correct(X: np.ndarray, subject_ids: np.ndarray, n_baseline: int) -> np.ndarray:
    """逐被试基线校正（与模型前端一致；aux 数据从 0ms 起时 n_baseline 用前若干点）。"""
    X = X.astype(np.float64).copy()
    for s in np.unique(subject_ids):
        m = subject_ids == s
        b = X[m, :, :n_baseline].mean(axis=2, keepdims=True)
        X[m] -= b
    return X


def _fwhm(d: np.ndarray, t: np.ndarray, i_peak: int, amp: float) -> float:
    """峰附近半高全宽（对负峰 amp<0 亦适用）。"""
    half = amp / 2.0
    left = i_peak
    while left > 0 and (d[left] - half) * np.sign(amp) > 0:
        left -= 1
    right = i_peak
    while right < len(d) - 1 and (d[right] - half) * np.sign(amp) > 0:
        right += 1
    return float(t[right] - t[left])


def calibrate(name: str, cache_dir: Path) -> dict:
    X, y, subj, t_ms, ch_names = _load_dataset(name, cache_dir)
    axis = EpochTimeAxis(
        tmin_ms=float(t_ms[0]),
        tmax_ms=float(t_ms[0] + 1000.0 * X.shape[2] / 256.0),
        sfreq=256.0,
        n_time=X.shape[2],
    )
    # GTN and MOABB caches both store volts; calibration reports microvolts.
    uv = 1e6
    result = calibrate_erp_fold(
        X * uv,
        y,
        subj,
        time_axis=axis,
        channel_names=ch_names,
    )
    result.update(
        dataset=name,
        calibration_scope="full_dataset_descriptive_not_for_loso",
        target_ratio=float(y.mean()),
        generated_utc=datetime.now(timezone.utc).isoformat(),
    )
    result["evidence"]["p3b"]["amp_uv"] = result["evidence"]["p3b"].pop("amplitude")
    result["evidence"]["p3b"]["snr"] = None
    return result


def main():
    ap = argparse.ArgumentParser(description="自适应 ERP 成分窗校准（新数据集接入前置步骤）")
    ap.add_argument("--dataset", required=True, choices=("gtn", "bnci008", "erpcore", "bi2014a"))
    ap.add_argument("--cache-dir", default="experiments/cache")
    args = ap.parse_args()

    calib = calibrate(args.dataset, Path(args.cache_dir))
    out = Path(args.cache_dir) / f"erp_calib_{args.dataset}.json"
    out.write_text(json.dumps(calib, indent=2, ensure_ascii=False), encoding="utf-8")

    ev = calib["evidence"]
    print(f"[calib:{args.dataset}] trials={calib['n_trials']} subjects={calib['n_subjects']}")
    print(f"[calib:{args.dataset}] P3b 峰={ev['p3b']['peak_ms']:.0f}ms 幅值={ev['p3b']['amp_uv']:.1f}μV "
          f"FWHM={ev['p3b']['fwhm_ms']:.0f}ms → σ={ev['p3b']['sigma_ms']:.0f}ms")
    print(f"[calib:{args.dataset}] N2 检出={ev['n2']['detected']} "
          f"峰={ev['n2']['peak_ms']}ms；P3a 检出={ev['p3a']['detected']} 峰={ev['p3a']['peak_ms']}ms")
    print(f"[calib:{args.dataset}] tau0_ms={[round(v) for v in calib['tau0_ms']]}")
    print(f"[calib:{args.dataset}] 已写入 {out}（描述性结果，禁止回灌同数据集 LOSO）")


if __name__ == "__main__":
    main()
