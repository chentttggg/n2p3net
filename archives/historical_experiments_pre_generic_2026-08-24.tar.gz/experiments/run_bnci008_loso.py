"""Standardized auxiliary-dataset LOSO engine; BNCI2014-008 entry point.

The entry point selects only the dataset. Neural-RIDE architecture, losses and
phase schedule come from train.recipe.NEURAL_RIDE_V8. Auxiliary binary tasks do
not have thought-number sets, so the recipe capability gate alone disables
L_digit while retaining PCW, reconstruction and phase supervision.

用法：
    .venv/Scripts/python.exe -u experiments/run_bnci008_loso.py --models n2p3net --epochs 30
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "src"
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

import numpy as np
import torch

from baselines.deep import DeepBaseline, DeepConfig  # noqa: E402
from baselines.evaluate import evaluate_binary, loso_folds  # noqa: E402
from baselines.n2p3net import N2P3NetBaseline  # noqa: E402
from data.auxiliary import (  # noqa: E402
    AuxiliaryDatasetSpec,
    get_auxiliary_dataset_spec,
    load_auxiliary,
)
from data.channel import build_channel_identity  # noqa: E402
from models.erp_calibration import FoldERPCalibrator  # noqa: E402
from models.time_axis import EpochTimeAxis  # noqa: E402
from train.recipe import BINARY_ODDBALL_TASK, NEURAL_RIDE_V8  # noqa: E402


def build_adapter(
    model_name: str,
    dataset_spec: AuxiliaryDatasetSpec,
    epochs: int,
    batch_size: int,
    early_stop_patience: int,
    *,
    erp_calib: dict | None = None,
    fold_calibration: bool = True,
    seed: int = 0,
    trainer_overrides: dict | None = None,
):
    n_channels = dataset_spec.n_channels
    ch_names = dataset_spec.channel_names
    profile = dataset_spec.preprocessing
    if model_name == "n2p3net":
        identity = build_channel_identity(ch_names=list(ch_names), channel_mask=(True,) * n_channels)
        if not bool(identity.mask.all()):
            missing = [name for name, valid in zip(ch_names, identity.mask, strict=True) if not valid]
            raise ValueError(
                f"Dataset {dataset_spec.name!r} has channels without registered coordinates: {missing}."
            )
        model_kwargs = NEURAL_RIDE_V8.model_kwargs(
            n_channels=n_channels,
            channel_names=ch_names,
            tmin_ms=profile.tmin_ms,
            tmax_ms=profile.tmax_ms,
            sfreq=profile.sfreq,
            n_time=profile.n_times,
            baseline_mode=profile.baseline_mode,
            residual_tmax_ms=800.0,
            # Fold calibration replaces these values using inner-subtrain data.
            tau0_ms=(200.0, 300.0, 460.0),
            tau0_bounds=((160.0, 280.0), (220.0, 420.0), (300.0, 700.0)),
            sigma_bounds=((20.0, 80.0), (20.0, 100.0), (40.0, 160.0)),
        )
        if erp_calib and fold_calibration:
            raise ValueError("fold_calibration and a frozen ERP prior are mutually exclusive.")
        if erp_calib:
            model_kwargs.update(
                tau0_ms=tuple(float(v) for v in erp_calib["tau0_ms"]),
                tau0_bounds=tuple(tuple(float(x) for x in b) for b in erp_calib["tau0_bounds"]),
                sigma_bounds=tuple(tuple(float(x) for x in b) for b in erp_calib["sigma_bounds"]),
            )
        overrides = dict(trainer_overrides or {})
        overrides["early_stop_patience"] = early_stop_patience
        trainer_config = NEURAL_RIDE_V8.trainer_config(
            BINARY_ODDBALL_TASK,
            epochs=epochs,
            batch_size=batch_size,
            seed=seed,
            overrides=overrides,
        )
        return N2P3NetBaseline(
            model_kwargs=model_kwargs,
            trainer_kwargs=asdict(trainer_config),
            E_chn=torch.from_numpy(identity.embedding),
            channel_mask=torch.ones(n_channels, dtype=torch.bool),
            val_subject_frac=dataset_spec.validation_subject_fraction,
            erp_calibrator=(
                FoldERPCalibrator(
                    EpochTimeAxis(
                        profile.tmin_ms, profile.tmax_ms, profile.sfreq, profile.n_times
                    ),
                    tuple(ch_names),
                )
                if fold_calibration
                else None
            ),
        )
    if model_name == "eegnet":
        return DeepBaseline(
            "eegnet",
            n_chans=n_channels,
            n_times=profile.n_times,
            sfreq=profile.sfreq,
            config=DeepConfig(epochs=epochs, batch_size=batch_size, seed=seed),
            device=None,
        )
    raise ValueError(model_name)


def main(*, default_dataset: str = "bnci008", lock_dataset: bool = True):
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser()
    ap.add_argument("--epochs", type=int, default=30)
    ap.add_argument("--batch-size", type=int, default=512)
    ap.add_argument("--early-stop-patience", type=int, default=NEURAL_RIDE_V8.early_stop_patience)
    ap.add_argument("--models", default="n2p3net",
                    help="逗号分隔：n2p3net/eegnet；通道由数据集规范唯一决定")
    ap.add_argument("--subjects", type=int, default=None, help="前 N 被试（benchmark 用）")
    ap.add_argument("--seed", type=int, default=0)
    if lock_dataset:
        dataset_name = default_dataset
    else:
        ap.add_argument(
            "--dataset",
            default=default_dataset,
            choices=("bnci008", "erpcore", "bi2014a"),
        )
    ap.add_argument("--cache-dir", default="experiments/cache")
    ap.add_argument("--run-name", default=None)
    ap.add_argument("--erp-calibration", default="fold", choices=("fold", "fixed"),
                    help="fold=每个外层折仅用内部训练被试校准（默认）；fixed=冻结人工/独立开发先验")
    ap.add_argument("--frozen-erp-prior", default=None,
                    help="独立开发集冻结先验 JSON；必须声明 calibration_scope=independent_development")
    ap.add_argument("--erp-calib", default=None, help=argparse.SUPPRESS)
    ap.add_argument("--lr", type=float, default=NEURAL_RIDE_V8.lr)
    ap.add_argument("--lambda2", type=float, default=NEURAL_RIDE_V8.lambda2)
    ap.add_argument("--lambda3", type=float, default=NEURAL_RIDE_V8.lambda3)
    ap.add_argument("--lambda-pcw", type=float, default=NEURAL_RIDE_V8.lambda_pcw)
    ap.add_argument("--lambda-recon", type=float, default=NEURAL_RIDE_V8.lambda_recon)
    ap.add_argument("--lambda-amp", type=float, default=NEURAL_RIDE_V8.lambda_amp)
    ap.add_argument(
        "--pcw-pretrain-epochs", type=int, default=NEURAL_RIDE_V8.pcw_pretrain_epochs
    )
    ap.add_argument(
        "--residual-ramp-epochs", type=int, default=NEURAL_RIDE_V8.residual_ramp_epochs
    )
    args = ap.parse_args()
    if not lock_dataset:
        dataset_name = args.dataset

    erp_calib = None
    if args.erp_calib:
        ap.error("--erp-calib 曾允许全数据校准并造成 LOSO 泄漏；请用默认 --erp-calibration fold，"
                 "或为独立开发先验使用 --frozen-erp-prior。")
    if args.frozen_erp_prior:
        erp_calib = json.loads(Path(args.frozen_erp_prior).read_text(encoding="utf-8"))
        if erp_calib.get("calibration_scope") != "independent_development":
            ap.error("--frozen-erp-prior 必须声明 calibration_scope=independent_development。")
    if args.erp_calibration == "fixed" and args.frozen_erp_prior is None:
        erp_calib = None  # 使用 build_adapter 中冻结的人工成人先验
    if args.erp_calibration == "fold" and args.frozen_erp_prior is not None:
        ap.error("--erp-calibration fold 与 --frozen-erp-prior 互斥。")

    dataset_spec = get_auxiliary_dataset_spec(
        dataset_name, preprocessing_profile="neural_ride_v8"
    )
    selected = [m.strip() for m in args.models.split(",") if m.strip()]
    unknown_models = set(selected) - {"n2p3net", "eegnet"}
    if unknown_models:
        ap.error(f"unknown models: {sorted(unknown_models)}")

    for model_name in selected:
        ch_names = dataset_spec.channel_names
        n_channels = dataset_spec.n_channels
        aux = load_auxiliary(
            dataset_spec.name,
            args.cache_dir,
            target_channels=ch_names,
            strict_channels=True,
            preprocessing_profile=dataset_spec.preprocessing.name,
        )
        X, y, subj = aux.X, aux.y, aux.subject_ids
        if X.shape[1:] != (n_channels, dataset_spec.preprocessing.n_times):
            raise ValueError(
                f"Dataset contract expects (C,T)={(n_channels, dataset_spec.preprocessing.n_times)}, "
                f"got {X.shape[1:]}."
            )
        if args.subjects:
            keep_subj = np.unique(subj)[: args.subjects]
            keep = np.isin(subj, keep_subj)
            X, y, subj = X[keep], y[keep], subj[keep]
        folds = loso_folds(subj)

        model_spec = f"{model_name}{n_channels}"
        run_name = args.run_name or f"{dataset_spec.name}_{NEURAL_RIDE_V8.name}"
        # GLM v3.1 修复：多模型 run 每模型独立子目录（runs/<run>/<spec>/）——
        # 此前 progress.jsonl/record.json 被后续模型覆盖（§15.4 遗留①）
        spec_dir = ROOT / "experiments" / "runs" / run_name / model_spec
        spec_dir.mkdir(parents=True, exist_ok=True)
        dashboard_run = f"{run_name}/{model_spec}"

        trainer_overrides = {
            "lr": args.lr,
            "lambda2": args.lambda2,
            "lambda3": args.lambda3,
            "lambda_pcw": args.lambda_pcw,
            "lambda_recon": args.lambda_recon,
            "lambda_amp": args.lambda_amp,
            "pcw_pretrain_epochs": args.pcw_pretrain_epochs,
            "residual_ramp_epochs": args.residual_ramp_epochs,
        }
        adapter = build_adapter(
            model_name,
            dataset_spec,
            args.epochs,
            args.batch_size,
            args.early_stop_patience,
            erp_calib=erp_calib,
            fold_calibration=args.erp_calibration == "fold",
            seed=args.seed,
            trainer_overrides=trainer_overrides,
        )

        # 逐 fold 实时进度（dashboard.html 消费；URL 用 ?run=<run_name>/<spec>）
        progress_f = (spec_dir / "progress.jsonl").open("w", encoding="utf-8")
        progress_f.write(json.dumps({
            "type": "manifest",
            "run_name": dashboard_run,
            "total_folds": len(folds),
            "n_trials": int(len(y)),
            "model_spec": model_spec,
            "dataset_spec": {
                "name": dataset_spec.name,
                "channel_names": list(dataset_spec.channel_names),
                "preprocessing": asdict(dataset_spec.preprocessing),
            },
            "recipe": (
                NEURAL_RIDE_V8.record(
                    BINARY_ODDBALL_TASK,
                    NEURAL_RIDE_V8.trainer_config(
                        BINARY_ODDBALL_TASK,
                        epochs=args.epochs,
                        batch_size=args.batch_size,
                        seed=args.seed,
                        overrides={**trainer_overrides, "early_stop_patience": args.early_stop_patience},
                    ),
                )
                if model_name == "n2p3net"
                else None
            ),
            "epochs": args.epochs,
            "batch_size": args.batch_size,
            "started_utc": datetime.now(timezone.utc).isoformat(),
        }, ensure_ascii=False) + "\n")
        progress_f.flush()

        def _on_fold(
            fold_idx: int,
            fold_result,
            *,
            _adapter=adapter,
            _progress_f=progress_f,
        ) -> None:
            hist = getattr(_adapter, "last_history", None) or {}
            fit_sec = (
                _adapter.fit_durations[-1]
                if getattr(_adapter, "fit_durations", None)
                else None
            )
            line = {
                "type": "fold",
                "fold": fold_idx,
                "n_folds_done": fold_idx + 1,
                "fold_bacc": float(fold_result.balanced_acc),
                "fold_auc": float(fold_result.auc),
                "fit_sec": float(fit_sec) if fit_sec else None,
                "epochs_ran": len(hist.get("train_losses", [])),
                "train_losses": [round(float(v), 4) for v in hist.get("train_losses", [])][-12:],
                "val_losses": [round(float(v), 4) for v in hist.get("val_losses", [])][-12:],
                "ts": datetime.now(timezone.utc).isoformat(),
            }
            _progress_f.write(json.dumps(line, ensure_ascii=False) + "\n")
            _progress_f.flush()

        t0 = time.perf_counter()
        summary = evaluate_binary(adapter, X, y, subj, folds, n_jobs=1, on_fold_end=_on_fold)
        wall = time.perf_counter() - t0
        progress_f.write(json.dumps({"type": "done", "ts": datetime.now(timezone.utc).isoformat()},
                                    ensure_ascii=False) + "\n")
        progress_f.close()

        fit_mean = None
        if isinstance(adapter, N2P3NetBaseline) and adapter.fit_durations:
            fit_mean = float(np.mean(adapter.fit_durations))
        print(f"[{model_name}-{n_channels}ch] subjects={len(np.unique(subj))} "
              f"bacc={summary.balanced_acc_mean:.4f}±{summary.balanced_acc_std:.4f} "
              f"auc={summary.auc_mean:.4f} wall={wall:.1f}s fit_mean={fit_mean}", flush=True)

        payload = {
            "model": f"{model_name}_{n_channels}ch",
            "run_name": dashboard_run,
            "n_subjects": int(len(np.unique(subj))),
            "epochs": args.epochs,
            "batch_size": args.batch_size,
            "config": NEURAL_RIDE_V8.name if model_name == "n2p3net" else "deep_baseline",
            "dataset_spec": {
                "name": dataset_spec.name,
                "channel_names": list(dataset_spec.channel_names),
                "preprocessing": asdict(dataset_spec.preprocessing),
            },
            "recipe": (
                {
                    "name": NEURAL_RIDE_V8.name,
                    "task": asdict(BINARY_ODDBALL_TASK),
                    "model_kwargs": adapter.model_kwargs,
                    "trainer_kwargs": adapter.trainer_kwargs,
                }
                if isinstance(adapter, N2P3NetBaseline)
                else None
            ),
            "balanced_acc_mean": summary.balanced_acc_mean,
            "balanced_acc_std": summary.balanced_acc_std,
            "auc_mean": summary.auc_mean,
            "transductive_balanced_acc_mean": summary.transductive_balanced_acc_mean,
            "erp_calibration": args.erp_calibration,
            "last_fold_erp_calibration": getattr(adapter, "last_erp_calibration", None),
            "wall_seconds": wall,
            "fit_mean_sec": fit_mean,
            "per_fold": [f.__dict__ for f in summary.per_fold],
            "finished_utc": datetime.now(timezone.utc).isoformat(),
        }
        (spec_dir / "record.json").write_text(
            json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"[record] {spec_dir / 'record.json'}", flush=True)
        # 兼容旧的汇总目录
        out = ROOT / "experiments" / "runs" / f"{dataset_spec.name}_loso_compare"
        out.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%SZ")
        (out / f"{model_name}_{n_channels}ch_{stamp}.json").write_text(
            json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


if __name__ == "__main__":
    main(default_dataset="bnci008", lock_dataset=True)
